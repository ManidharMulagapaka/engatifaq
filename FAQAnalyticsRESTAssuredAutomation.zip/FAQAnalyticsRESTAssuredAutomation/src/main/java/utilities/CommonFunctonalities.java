package utilities;

public class CommonFunctonalities {
}
