package envSetters;

public class InteractionsEnvSetter {
}
