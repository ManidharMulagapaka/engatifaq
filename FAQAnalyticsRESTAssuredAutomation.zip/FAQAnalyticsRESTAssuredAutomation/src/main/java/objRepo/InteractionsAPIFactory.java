package objRepo;

public class InteractionsAPIFactory {
}
