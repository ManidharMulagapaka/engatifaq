package implementations;

public class FAQTrainBot {
}
