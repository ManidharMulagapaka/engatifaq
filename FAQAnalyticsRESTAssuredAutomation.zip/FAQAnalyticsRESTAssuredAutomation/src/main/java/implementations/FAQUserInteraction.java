package implementations;

public class FAQUserInteraction {
}
