package implementations;

public class FAQViewExportHistory {
}
