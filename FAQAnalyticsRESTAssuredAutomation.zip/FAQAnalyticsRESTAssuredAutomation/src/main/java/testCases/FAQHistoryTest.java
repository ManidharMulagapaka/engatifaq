package testCases;

public class FAQHistoryTest {
}
