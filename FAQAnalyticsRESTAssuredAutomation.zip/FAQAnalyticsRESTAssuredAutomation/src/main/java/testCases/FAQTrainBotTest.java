package testCases;

public class FAQTrainBotTest {
}
