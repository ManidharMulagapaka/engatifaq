package testCases;

public class FAQHistorySearchTest {
}
