package testCases;

public class FAQUserInteractionsTest {
}
