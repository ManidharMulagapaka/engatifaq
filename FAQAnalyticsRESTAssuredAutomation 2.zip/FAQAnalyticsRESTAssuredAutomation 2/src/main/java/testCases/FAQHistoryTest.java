package testCases;

import envSetters.HistoryEnvSetter;
import implementations.FAQHistory;
import implementations.FAQHistorySearch;
import io.restassured.http.Cookie;
import io.restassured.path.json.JsonPath;
import objRepo.HistoryAPIFactory;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.testng.annotations.Test;
import utilities.CommonFunctonalities;

import java.io.IOException;
import java.sql.Driver;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FAQHistoryTest extends CommonFunctonalities{
    static Logger logger = Logger.getLogger(Driver.class.getName());

    @Test
    public static void buildFaqAnalyticsVerify() throws IOException {
        logger.log(Level.INFO,"starting the test for search history");
        Cookie cookie = CommonFunctonalities.getCookie();
        JsonPath path = CommonFunctonalities.returnResponse(cookie, HistoryAPIFactory.Searching, HistoryEnvSetter.Ok);
        logger.log(Level.INFO,"The server gave a response");
        FAQHistory.buildFaqAnalyticsVerify(path);
        logger.log(Level.INFO,"ending the test for search history");
    }

    @Test
    public static void partialFaqAnalyticsVerify() throws IOException {
        logger.log(Level.INFO,"starting the test for partial search history");
        Cookie cookie = CommonFunctonalities.getCookie();
        JsonPath jsonPath = CommonFunctonalities.returnResponse(cookie, HistoryAPIFactory.Searching, HistoryEnvSetter.Ok);
        logger.log(Level.INFO,"The server gave a response");
        FAQHistory.partialFaqAnalyticsVerify(jsonPath);
        logger.log(Level.INFO,"ending the test for partial search history");
    }

    @Test
    public static void nonExistingFaqAnalyticsVerify() throws IOException {
        logger.log(Level.INFO,"starting the test for non-existing search history");
        Cookie cookie = CommonFunctonalities.getCookie();
        JsonPath jsonPath = CommonFunctonalities.returnResponse(cookie, HistoryAPIFactory.Searching, HistoryEnvSetter.Ok);
        logger.log(Level.INFO,"The server gave a response");
        FAQHistory.nonExistingFaqAnalyticsVerify(jsonPath);
        logger.log(Level.INFO,"ending the test for non-existing search history");
    }

    @Test
    public static void paginationValidation() throws IOException {
        logger.log(Level.INFO,"starting the test for pagination in search history");
        Cookie cookie = CommonFunctonalities.getCookie();
        JsonPath jsonPath = CommonFunctonalities.returnResponse(cookie, HistoryAPIFactory.Searching, HistoryEnvSetter.Ok);
        logger.log(Level.INFO,"The server gave a response");
        FAQHistory.paginationValidation();
        logger.log(Level.INFO,"Ending the test for pagination in search history");
    }

    @Test
    public void checkingDate24Hours() throws IOException {
        logger.log(Level.INFO,"starting the test for checking data in between 24 hours");
        Cookie cookie = CommonFunctonalities.getCookie();
        String url = CommonFunctonalities.getUrl(HistoryEnvSetter.startOneDay, HistoryEnvSetter.endOneDay);
        JsonPath path = CommonFunctonalities.returnResponse(cookie, url, HistoryEnvSetter.Ok);
        logger.log(Level.INFO,"The server gave a response");
        ArrayList arrayList = CommonFunctonalities.getArrayList(path, CommonFunctonalities.DataFetched);
        DateTime start = CommonFunctonalities.getTime(HistoryEnvSetter.startOneDay);
        DateTime end = CommonFunctonalities.getTime(HistoryEnvSetter.endOneDay);
        FAQHistorySearch.checkingDate(start, end, path, arrayList);
        logger.log(Level.INFO,"ending the test for checking data in betweeen 24 hours");
    }

    @Test
    public void checkingDate7Days() throws ParseException, IOException {
        logger.log(Level.INFO,"starting the test for checking data in between 7 days");
        Cookie cookie = CommonFunctonalities.getCookie();
        String url = CommonFunctonalities.getUrl(HistoryEnvSetter.startSevenDay, HistoryEnvSetter.endSevenDay);
        JsonPath path = CommonFunctonalities.returnResponse(cookie, url, HistoryEnvSetter.Ok);
        logger.log(Level.INFO,"The server gave a response");
        ArrayList arrayList = CommonFunctonalities.getArrayList(path, CommonFunctonalities.DataFetched);
        DateTime start = CommonFunctonalities.getTime(HistoryEnvSetter.startSevenDay);
        DateTime end = CommonFunctonalities.getTime(HistoryEnvSetter.endSevenDay);
        FAQHistorySearch.checkingDate(start, end, path, arrayList);
        logger.log(Level.INFO,"ending the test for checking data in between 7 days");
    }

    @Test
    public void checkingDateBetweenRages() throws IOException {
        logger.log(Level.INFO,"starting the test for checking data in between different date Ranges");
        Cookie cookie = CommonFunctonalities.getCookie();
        String url = CommonFunctonalities.getUrl(HistoryEnvSetter.startRange, HistoryEnvSetter.endRange);
        JsonPath path = CommonFunctonalities.returnResponse(cookie, url, HistoryEnvSetter.Ok);
        logger.log(Level.INFO,"The server gave a response");
        ArrayList arrayList = CommonFunctonalities.getArrayList(path, CommonFunctonalities.DataFetched);
        DateTime start = CommonFunctonalities.getTime(HistoryEnvSetter.startRange);
        DateTime end = CommonFunctonalities.getTime(HistoryEnvSetter.endRange);
        FAQHistorySearch.checkingDate(start, end, path, arrayList);
        logger.log(Level.INFO,"ending the test for checking data in between different date Ranges");
    }

    @Test
    public void checkingForInvalidDateValues() throws IOException {
        logger.log(Level.INFO,"starting the test for invalid dates");
        Cookie cookie = CommonFunctonalities.getCookie();
        String url = CommonFunctonalities.getUrl(HistoryEnvSetter.startDate, HistoryEnvSetter.endDate);
        JsonPath path = CommonFunctonalities.returnResponse(cookie, url, HistoryEnvSetter.NotFound);
        logger.log(Level.INFO,"The server gave the expected Invalid response");
        logger.log(Level.INFO,"ending the test for invalid dates");
    }

}



