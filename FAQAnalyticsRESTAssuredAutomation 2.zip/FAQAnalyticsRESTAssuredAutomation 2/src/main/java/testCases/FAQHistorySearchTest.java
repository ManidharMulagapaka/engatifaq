package testCases;

import envSetters.HistoryEnvSetter;
import implementations.FAQHistory;
import io.restassured.http.Cookie;
import io.restassured.path.json.JsonPath;
import objRepo.HistoryAPIFactory;
import org.junit.Assert;
import org.testng.annotations.Test;
import utilities.CommonFunctonalities;

import java.io.IOException;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FAQHistorySearchTest extends CommonFunctonalities {

    static Logger logger = Logger.getLogger(Driver.class.getName());

    @Test
    public void searchTest()  {

        logger.log(Level.INFO, "Starting the Test for poistive Test");
        Cookie cookie = CommonFunctonalities.getCookie();
        JsonPath path = CommonFunctonalities.returnResponse(cookie, HistoryAPIFactory.validSearch, HistoryEnvSetter.Ok);
        logger.log(Level.INFO, "The server has given back a response");
        ArrayList arr = CommonFunctonalities.getArrayList(path, CommonFunctonalities.DataFetched);
        FAQHistory.verifyingSearch(path, arr);
        logger.log(Level.INFO, "Ending the Test for poistive search");
    }

    @Test
    public void negativeSearchTest()  {

        logger.log(Level.INFO, "Starting the Test for poistive Test");
        Cookie myCookie = CommonFunctonalities.getCookie();
        JsonPath path = CommonFunctonalities.returnResponse(myCookie, HistoryAPIFactory.InvaidSearch, HistoryEnvSetter.Ok);
        logger.log(Level.INFO, "The server has given back a response");
        ArrayList arr = CommonFunctonalities.getArrayList(path, CommonFunctonalities.DataFetched);
        Assert.assertTrue("The search is not working", arr.size() == 0);
        logger.log(Level.INFO, "Ending the Test for negative search");
    }


}
