package testCases;

import envSetters.HistoryEnvSetter;
import implementations.FAQViewExportHistory;
import io.restassured.http.Cookie;
import io.restassured.path.json.JsonPath;
import objRepo.ViewExportHistoryAPIFactory;
import org.testng.annotations.Test;
import utilities.CommonFunctonalities;

import java.io.IOException;
import java.sql.Driver;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FAQViewExportHistoryTest extends CommonFunctonalities{
    static Logger logger = Logger.getLogger(Driver.class.getName());
    @Test
    public void exportViewHistory() throws IOException {
        logger.log(Level.INFO,"Starting the test for export view history");
        Cookie cookie = CommonFunctonalities.getCookie();
        JsonPath path = CommonFunctonalities.returnResponse(cookie, ViewExportHistoryAPIFactory.viewExportHistory, HistoryEnvSetter.Ok);
        FAQViewExportHistory.verifyingData(path);
        logger.log(Level.INFO,"The server gave a response");
        logger.log(Level.INFO,"Ending the test for export view history");
    }
}


