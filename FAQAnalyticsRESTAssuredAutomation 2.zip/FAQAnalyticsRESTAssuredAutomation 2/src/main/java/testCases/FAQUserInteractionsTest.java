package testCases;

import envSetters.HistoryEnvSetter;
import implementations.FAQUserInteraction;
import io.restassured.http.Cookie;
import io.restassured.path.json.JsonPath;
import objRepo.TrainBotAPIFactory;
import org.testng.annotations.Test;
import utilities.CommonFunctonalities;

import java.io.IOException;
import java.sql.Driver;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FAQUserInteractionsTest extends CommonFunctonalities {
    static Logger logger = Logger.getLogger(Driver.class.getName());

    @Test
    public void checkingUserInteractions() throws IOException {
        logger.log(Level.INFO, "Starting the test for User Interactions");
        Cookie myCookie = CommonFunctonalities.getCookie();
        JsonPath jsonPath = CommonFunctonalities.returnResponsePost(myCookie, TrainBotAPIFactory.UserInteractions, HistoryEnvSetter.Ok, TrainBotAPIFactory.faqbody);
        FAQUserInteraction.verifyInformation(jsonPath);
        logger.log(Level.INFO, "The server gave a response");
        logger.log(Level.INFO, "Ending the test for User Interactions");
    }
}
