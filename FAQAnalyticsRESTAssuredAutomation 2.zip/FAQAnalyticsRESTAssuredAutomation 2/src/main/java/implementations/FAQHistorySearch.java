package implementations;

import com.jayway.jsonpath.JsonPathException;
import io.restassured.path.json.JsonPath;
import org.joda.time.DateTime;
import org.junit.Assert;
import utilities.CommonFunctonalities;

import java.sql.Driver;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FAQHistorySearch {

    static Logger logger = Logger.getLogger(Driver.class.getName());

    public static void checkingDate(DateTime start, DateTime end, JsonPath path, ArrayList arrayList) {
        try {
            for (int i = 0; i < arrayList.size(); i++) {
                String strDate = path.get("faq_analytics_data[" + i + "].date_time");
                DateTime dateTime = CommonFunctonalities.getTime(strDate);
                Assert.assertTrue("The data is not in the range", dateTime.isAfter(start) && dateTime.isBefore(end));
            }
        } catch (JsonPathException exception) {
            logger.log(Level.INFO, "Json is not getting parsed");
        }

    }

}
