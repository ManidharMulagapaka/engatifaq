package implementations;

import com.jayway.jsonpath.JsonPathException;
import io.restassured.path.json.JsonPath;
import org.testng.Assert;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FAQViewExportHistory {
    static Logger logger = Logger.getLogger(Driver.class.getName());

    public static void verifyingData(JsonPath path) {

        try {
            ArrayList arrayList = path.get("responseObject.content");
            for (int i = 0; i < arrayList.size(); i++) {
                String file = path.get("responseObject.content[" + i + "].fileName");
                String status = path.get("responseObject.content[" + i + "].status");
                Assert.assertTrue(file.contains("csv"), "The file format is wrong");
                Assert.assertTrue(status.equals("SUCCESS"), "The file cannot be downloaded");
            }
        } catch (JsonPathException exception) {
            logger.log(Level.INFO, "The json path cannot be parsed");
        }
    }
}
