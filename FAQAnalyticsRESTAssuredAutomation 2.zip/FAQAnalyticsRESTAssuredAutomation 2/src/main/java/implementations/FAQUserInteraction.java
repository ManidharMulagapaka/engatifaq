package implementations;

import com.jayway.jsonpath.JsonPathException;
import envSetters.HistoryEnvSetter;
import io.restassured.path.json.JsonPath;
import org.testng.Assert;

import java.sql.Driver;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FAQUserInteraction {
    static Logger logger = Logger.getLogger(Driver.class.getName());

    public static void verifyInformation(JsonPath jsonPath) {
        try {
            ArrayList arrayList = jsonPath.get("msg_cloud_data");
            Assert.assertTrue(arrayList.size() == HistoryEnvSetter.numberOfInteractions, "The number of interactions done is wrong");
        } catch (JsonPathException exception) {
            logger.log(Level.INFO, "Json is not getting parsed");
        }
    }
}
