package implementations;

import com.jayway.jsonpath.JsonPathException;
import envSetters.HistoryEnvSetter;
import io.restassured.path.json.JsonPath;
import objRepo.HistoryAPIFactory;
import org.testng.Assert;
import utilities.CommonFunctonalities;

import java.io.IOException;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import static java.lang.Math.ceil;
import static java.util.Objects.isNull;

public class FAQHistory {

    static Logger logger = Logger.getLogger(Driver.class.getName());

    public static void verifyingSearch(JsonPath jsonPath, ArrayList arrayList) {
        try {
            for (int i = 0; i < arrayList.size(); i++) {
                String question = jsonPath.get("faq_analytics_data[" + i + "].question");
                String answer = jsonPath.get("faq_analytics_data[" + i + "].answer");
                org.junit.Assert.assertTrue("The search is not working", question.contains("k") || answer.contains("k"));
            }
        } catch (JsonPathException exception) {
            logger.log(Level.INFO, "Json is not getting parsed");
        }
    }

    public static void buildFaqAnalyticsVerify(JsonPath jsonPath) throws IOException {
        try {
            ArrayList question = CommonFunctonalities.getArrayList(jsonPath, CommonFunctonalities.DataFetched);
            for (int i = 0; i < 10; i++) {
                String query = jsonPath.get("faq_analytics_data[" + i + "].question");
                String response = jsonPath.get("faq_analytics_data[" + i + "].answer");

                if (isNull(HistoryEnvSetter.requestResponseMap.get(query)) == false) {

                    Assert.assertTrue(HistoryEnvSetter.requestResponseMap.get(query).equals(response), "Failed with the built FAQ");
                }
            }
        } catch (JsonPathException exception) {
            logger.log(Level.INFO, "Json is not getting parsed");
        }
    }

    public static void partialFaqAnalyticsVerify(JsonPath jsonPath) throws IOException {
        try {
            ArrayList question = CommonFunctonalities.getArrayList(jsonPath, CommonFunctonalities.DataFetched);
            String ans;
            for (int i = 0; i < 10; i++) {
                String query = jsonPath.get("faq_analytics_data[" + i + "].question");
                String response = jsonPath.get("faq_analytics_data[" + i + "].answer");

                if (isNull(HistoryEnvSetter.partialReqResMap.get(query)) == false && response.length() > 1) {
                    Assert.assertTrue(HistoryEnvSetter.partialReqResMap.get(query).equals(response), "Failed with the built FAQ");
                }
            }
        } catch (JsonPathException exception) {
            logger.log(Level.INFO, "Json is not getting parsed");
        }
    }

    public static void nonExistingFaqAnalyticsVerify(JsonPath jsonPath) throws IOException {
        try {
            ArrayList question = CommonFunctonalities.getArrayList(jsonPath, CommonFunctonalities.DataFetched);
            for (int i = 0; i < 10; i++) {
                String query = jsonPath.get("faq_analytics_data[" + i + "].question");
                String response = jsonPath.get("faq_analytics_data[" + i + "].answer");
                if (response.equals("Fallback Msg Shown"))
                    Assert.assertTrue(isNull(HistoryEnvSetter.requestResponseMap.get(query)), "Failed with the non-existing FAQ");
            }
        } catch (JsonPathException exception) {
            logger.log(Level.INFO, "Json is not getting parsed");
        }

    }

    public static void paginationValidation() throws IOException {

        HistoryEnvSetter.historyProperties();
        try {
            for (String entry : HistoryEnvSetter.entries) {
                String url = HistoryAPIFactory.paginationUrlhalf1 + "100" + HistoryAPIFactory.paginationUrlhalf2 + entry + HistoryAPIFactory.paginationUrlhalf3;
                JsonPath jsonPath = CommonFunctonalities.returnResponse(CommonFunctonalities.getCookie(), url, HistoryEnvSetter.Ok);
                int totalItems = jsonPath.get("total_items");

                for (int i = 1; i <= ceil(totalItems / (double) Integer.parseInt(entry)); i++) {
                    url = HistoryAPIFactory.paginationUrlhalf1 + new Integer(i).toString() + HistoryAPIFactory.paginationUrlhalf2 + entry + HistoryAPIFactory.paginationUrlhalf3;
                    jsonPath = CommonFunctonalities.returnResponse(CommonFunctonalities.getCookie(), url, HistoryEnvSetter.Ok);
                    ArrayList<String> historyList = jsonPath.get("faq_analytics_data");
                    if (historyList.size() != Integer.parseInt(entry))
                        Assert.assertTrue(i == ceil(totalItems / (double) Integer.parseInt(entry)), "Entries are not split as per the entry");
                }
            }
        } catch (JsonPathException exception) {
            logger.log(Level.INFO, "Json is not getting parsed");
        }

    }


}