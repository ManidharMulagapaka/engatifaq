package envSetters;

import utilities.CommonFunctonalities;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class HistoryEnvSetter {

    public static Map<String, String> requestResponseMap = new HashMap<>();
    public static Map<String, String> partialReqResMap = new HashMap<>();
    public static String[] request;
    public static String[] response;
    public static String[] partialRequest;
    public static String[] entries;
    public static String startOneDay;
    public static String endOneDay;
    public static String startSevenDay;
    public static String endSevenDay;
    public static String startRange;
    public static String endRange;
    public static String startDate;
    public static String endDate;
    public static int Ok;
    public static int NotFound;
    public static int numberOfInteractions;

    public static void historyProperties() throws IOException {
        Properties properties = CommonFunctonalities.extractProperties("/Users/kanimozhin/Downloads/FAQAnalyticsRESTAssuredAutomation 2/src/main/resources/historytest.properties");
        request = properties.getProperty("buildrequest").split(",");
        response = properties.getProperty("response").split(",");
        partialRequest = properties.getProperty("partialrequest").split(",");

        for (int i = 0; i < request.length; i++) {
            requestResponseMap.put(request[0], response[0]);
            partialReqResMap.put(partialRequest[0], response[0]);
        }
        entries = properties.getProperty("entries").split(",");
        startOneDay = properties.getProperty("start");
        endOneDay = properties.getProperty("end");
        startSevenDay = properties.getProperty("start7days");
        endSevenDay = properties.getProperty("end7days");
        startRange = properties.getProperty("startRange");
        endRange = properties.getProperty("endRange");
        startDate = properties.getProperty("WrongDate");
        endDate = properties.getProperty("RightDate");
        Ok = Integer.parseInt(properties.getProperty("OK"));
        NotFound = Integer.parseInt(properties.getProperty("NotFound"));
        numberOfInteractions=Integer.parseInt(properties.getProperty("numberOfInteractions"));

    }
}