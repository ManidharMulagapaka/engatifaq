package utilities;

import envSetters.HistoryEnvSetter;
import io.restassured.http.Cookie;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

import static io.restassured.RestAssured.given;
import static org.hamcrest.number.OrderingComparison.lessThan;

public class CommonFunctonalities {

    @BeforeTest
        public void initialize() throws IOException {
        HistoryEnvSetter.historyProperties();
        }

    static public String DataFetched = "faq_analytics_data";

    static public String Session = ".eJytV1tv4joQ_isV57WFXCHp05rE0GhDnE0MVc92ZZnEgWhDgkho1V3tfz_OBUogZXWk8sDF83nmm2_G4_C7R6Idy9e9-2K3Z7c9Eoe9-14os5AFsqqMAlXQR7IYBaIaiKOlwlRVo0slEsKA6VKkRJIYCOFQlkRRjpaqwrRI1LRAVamilS8pFCIaKJIeaJEmjUaKomiKJlCBqcNQGKnDoaJIqhpGgqhRJgthKEs67XEiW7bb0JSlxYHaPme7mt7v5x4NiviFkWVWPPfub5574lCWn3u3_FtKN6xe49vjcE13N5t9Qld0S3_SGlJkP1na7JMNQxrpgqkJpqIakm4OoQHGujjRgQEFo97Aw5Adi8ot33kk6famjFe-q2r1rv8oYWxD46QdW9e-rMrVfpBtal_RkjSZlMh0nyS3FT4v-CINN3FKgrat-SmJkn4B3behyx1NwzhdkZAVPGpe2rhacU5YuqJFTCpAuVppyndAZwqwRcbAcaBH5p5d818XxTa_HwxyuU-3d3m2L9Z3Yp9u6K8spa95mc7gEOyON1C23wUsH4QsovukGNTR7pY0TdnuLt6s-tt0VeffBJyAhWUgh7gAP3xKyIi-xEGWtoI8wrHxADDBD3AGiYFs5NWx_gkViUrLc7BvYfiuwevra79O5L16DRY6YGxDk_jIsIBNXA8tLBN6fr3x-83vm-dn3qQ8BXeXvcQh25W_b-6r5SlCUxtWC7fVAkvDbRanxQnmRW40HCTZKk4HqyxbJexkTxjn24S-OWW3n7g-wv5w3FUWE97fY4S-_j8eHbu6mUxowJZZ9rPi8qMlngenlo89_rWq_xQSa1a-f3LzbbJlnLCLxjORQSbI5tXiTe_Dz2vAMAvyViQfzFwb8k7_RiYWL_gnBGn5r87PJ4sWrGlxV56j_iqO6mhf4VMdoYvDZAxcl1hmjZAFWVaGw6HAJ7uoym015q6LPEzgDFgN5bo_X2iyP-2cfL_dZrviy8nRe2-24m17iq0nbtlirViuDfAEeTPigFmjO6y8dXD3oeFB3NwGylKKhppEIzUIqaxqAVVERVsGuixKQai0g3jWAhhPxEW2xT8uCvHOf-Du4hcavLlZEgdv_XWxSVqeMPRmPh9PjmlVZ-KaK8yvxRxF85xd-nEQtiaWUR-sE53TrIijOOAusvTLBxPNhx4fyJAAw0BzBx9LKnFtq7stLeIiYRv-ebhVjLmP0YyfIy6306jcOMPA40nVAY6wg2v85DZFOZjOsiBoQiyHOwBGmUpTG0EQDrhy-JIa3r7LKgMwF2TsAa6mMy3NEU3yU_sClYmOEe4yNiSAa_ldZttawPJKOdoqcWjAj1Luxav1URwMwazKlMxdE-Aq4e_SUFeqJwWjZFcukxlwytlnQszL5XPuM8tpY989LSz4eOYH8REDuFZk7kOvbWs8PwJsPDRX04XRg4_AM7ui2hDwETlGpfkyLgb-165d_CmCl9jgty2nhB6dc05TiD8g5CH7KIbNr4e2dQzMKewK2OzgF_BhxJ6QwX5FnZjAf6gyOSPDh8PHunVVAthlXjOIPcvweYuaFr_258BuwxoyV-geS3qmgeNd2cQfMADpSKOleY1tA77NrX-v-AUftUBjLxXqbGIP-tbUqacNn-6wk_xR-0Y23nLA7Izjz70FfCJ8fMEp8izoXxX_b_lc9mxV7hpz3pUIdB89JKG_dvmHDdQQNp6M88ZsAMib8rGLMR9TV0_nZSqnbXRemWogNX8LRP43ZfSn9-c_7gEhkA.DzMO_g.GND2gGSoV21DigHQ3XTVmbKI6qQ";

    static public Cookie getCookie(){
        Cookie cookie = new Cookie.Builder("session", CommonFunctonalities.Session)
                .setSecured(true)
                .build();
        return cookie;
    }
    public static Properties extractProperties(String filePath)throws IOException {
        FileInputStream fileIoStream = new FileInputStream(filePath);
        Properties properties =new Properties();
        properties.load(fileIoStream);
        return properties;

    }

    public static JsonPath returnResponse(Cookie cookie, String url,int statusCode)
    {

            Response response = given().cookie(cookie).when().get(url).then().time(lessThan(3000L)).assertThat().statusCode(statusCode).extract().response();
            return new JsonPath(response.asString());


    }

    public static JsonPath returnResponsePost(Cookie cookie, String url,int statusCode,String bodyPart)
    {

        Response response = given().cookie(cookie).header("Content-Type","application/json").body(bodyPart).when().post(url).then().assertThat().statusCode(statusCode).extract().response();
        return new JsonPath(response.asString());


    }
    public static String getUrl(String start,String end){
        return "https://dev.engati.com/portal/api/v1/faqAnalytics/?answer_shown=any&fromdate="+start+"&page_num=1&page_size=25&q=&response_helpful=Any&todate="+end;

    }

    public static DateTime getTime(String strDate){
        strDate =strDate.replace("T"," ");
        strDate = strDate.replace("Z"," ");
        strDate = strDate.trim();
        if(strDate.length()  > 19)
            strDate = strDate.substring(0, strDate.length() - 4);
        DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
        DateTime historyDateTime = formatter.parseDateTime(strDate);
        return historyDateTime;
    }

    public static ArrayList getArrayList(JsonPath path,String data){
        return path.get(data);
    }

}
