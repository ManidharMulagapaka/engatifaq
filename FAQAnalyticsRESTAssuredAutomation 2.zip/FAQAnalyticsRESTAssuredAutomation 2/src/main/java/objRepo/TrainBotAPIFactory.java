package objRepo;

public class TrainBotAPIFactory {
    static public String path = "https://dev.engati.com/portal/api/v1/getMatchingAnswers?query=how%20to%20book%20a%20ticket";

    static public String UserInteractions = "https://dev.engati.com/portal/api/v1/userDetails/";

    static public String faqbody = "{\"user_id\": \"1e67a7e9-338b-40e2-98f8-dbdce31f6116\"}";
}
