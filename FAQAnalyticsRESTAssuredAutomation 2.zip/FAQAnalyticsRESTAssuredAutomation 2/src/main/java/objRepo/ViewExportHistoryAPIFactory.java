package objRepo;

public class ViewExportHistoryAPIFactory {
    public static String viewExportHistory = "https://dev.engati.com/portal/api/v1/export/history/?page=0&size=25&sort=createdOn,desc&workflow=FAQ_ANALYTICS";
}
