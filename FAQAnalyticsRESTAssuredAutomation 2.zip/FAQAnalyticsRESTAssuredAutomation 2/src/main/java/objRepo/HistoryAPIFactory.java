package objRepo;

public class HistoryAPIFactory {

    public static String paginationUrlhalf1 = "https://dev.engati.com/portal/api/v1/faqAnalytics/?answer_shown=Any&fromdate=&page_num=";

    public static String paginationUrlhalf2 = "&page_size=";

    public static String paginationUrlhalf3 = "&q=&response_helpful=Any&todate=";

    public static String validSearch = "https://dev.engati.com/portal/api/v1/faqAnalytics/?answer_shown=Any&fromdate=&page_num=1&page_size=25&q=k&response_helpful=Any&todate=";

    public static String Searching = "https://dev.engati.com/portal/api/v1/faqAnalytics/?answer_shown=Any&fromdate=&page_num=1&page_size=25&q=&response_helpful=Any&todate=";

    public static String InvaidSearch = "https://dev.engati.com/portal/api/v1/faqAnalytics/?answer_shown=Any&fromdate=&page_num=1&page_size=25&q=qwwee&response_helpful=Any&todate=";
}
