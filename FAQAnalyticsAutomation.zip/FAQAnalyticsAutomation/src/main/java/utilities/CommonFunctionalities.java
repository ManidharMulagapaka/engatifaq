package utilities;

import objectrepo.HistoryPageFactory;
import objectrepo.InteractionsPageFactory;
import objectrepo.TrainBotPageFactory;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Properties;

import static java.util.Objects.isNull;

public class CommonFunctionalities {

    public static void openBot(String[] xpaths) throws InterruptedException {

        for (String xpath: xpaths
                ) {
            Utility.driver.findElement(By.xpath(xpath)).click();
            Thread.sleep(2000);
        }

        Utility.driver.findElement(By.xpath(HistoryPageFactory.faqAnalyticsTab)).click();
        Thread.sleep(3000);

    }

    public static Properties extractProperties(String filePath)throws IOException {
        FileInputStream fileIoStream = new FileInputStream(filePath);
        Properties properties =new Properties();
        properties.load(fileIoStream);
        return properties;

    }
    public static void selectFilters(String responseType){
        Utility.driver.findElement(By.xpath(HistoryPageFactory.responseTypeButton)).click();
        List<WebElement> responses = Utility.driver.findElements(By.xpath(HistoryPageFactory.responseTypedropdown));
        for (int i=1;i<=responses.size();i++
             ) {
            WebElement element = Utility.driver.findElement(By.xpath("(" + HistoryPageFactory.responseTypedropdown + HistoryPageFactory.responsedivision + ")" + "[" + i + "]"));
            if (element.getText().equals(responseType))
                element.click();
        }
        Utility.driver.findElement(By.id(HistoryPageFactory.responseHelpfulButton)).click();
        Utility.driver.findElement(By.xpath(HistoryPageFactory.responseHelpfulValue)).click();

    }
    public static void trainBot(WebElement trainButton,String[] questions,String response) throws InterruptedException {

        boolean staleElement = true;
        while(staleElement){
            try{
                trainButton.click();
                staleElement = false;

            } catch(WebDriverException e){
                staleElement = true;
            }
        }
        Thread.sleep(3000);
        if(isNull(questions))
        {
            Utility.driver.findElement(By.xpath(TrainBotPageFactory.addNewResponse)).sendKeys(response);
            Utility.driver.findElement(By.xpath(TrainBotPageFactory.addButton)).click();
        }
        else{

            Utility.driver.findElement(By.xpath(TrainBotPageFactory.addNewResponse)).sendKeys(response);
            for (String question:questions
                 ) {
                Utility.driver.findElement(By.xpath(TrainBotPageFactory.addQuestions)).sendKeys(question, Keys.ENTER);
            }

            Utility.driver.findElement(By.xpath(TrainBotPageFactory.addButton)).click();
        }

    }
}
