package utilities;

import objectrepo.HistoryPageFactory;
import objectrepo.TrainBotPageFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Driver;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import static java.util.Objects.isNull;

public class CommonFunctionalities {

    static Logger logger = Logger.getLogger(Driver.class.getName());

    public static void openBot(String[] xpaths) throws InterruptedException {

        for (String xpath : xpaths
                ) {
            Utility.driver.findElement(By.xpath(xpath)).click();
            Thread.sleep(2000);
        }
        logger.log(Level.INFO, "Bot related to the test is selected ");


        Utility.driver.findElement(By.xpath(HistoryPageFactory.faqAnalyticsTab)).click();
        logger.log(Level.INFO, "Opening the 'FAQ Analytics' Tab ");
        Thread.sleep(3000);

    }

    public static Properties extractProperties(String filePath) throws IOException {
        FileInputStream fileIoStream = new FileInputStream(filePath);
        Properties properties = new Properties();
        properties.load(fileIoStream);
        return properties;

    }

    public static void selectFilters(String responseType) {
        Utility.driver.findElement(By.xpath(HistoryPageFactory.responseTypeButton)).click();
        List<WebElement> responses = Utility.driver.findElements(By.xpath(HistoryPageFactory.responseTypedropdown));
        for (int i = 1; i <= responses.size(); i++
                ) {
            WebElement element = Utility.driver.findElement(By.xpath("(" + HistoryPageFactory.responseTypedropdown + HistoryPageFactory.responsedivision + ")" + "[" + i + "]"));
            if (element.getText().equals(responseType))
                element.click();
        }
        Utility.driver.findElement(By.id(HistoryPageFactory.responseHelpfulButton)).click();
        Utility.driver.findElement(By.xpath(HistoryPageFactory.responseHelpfulValue)).click();

    }

    public static void trainBot(WebElement trainButton, String[] questions, String response) throws InterruptedException {
        trainButton.click();
        Thread.sleep(3000);
        if (isNull(questions)) {
            Utility.driver.findElement(By.xpath(TrainBotPageFactory.addNewResponse)).sendKeys(response);
            Utility.driver.findElement(By.xpath(TrainBotPageFactory.addButton)).click();
        } else {

            Utility.driver.findElement(By.xpath(TrainBotPageFactory.addNewResponse)).sendKeys(response);
            for (String question : questions
                    ) {
                Utility.driver.findElement(By.xpath(TrainBotPageFactory.addQuestions)).sendKeys(question, Keys.ENTER);
            }

            Utility.driver.findElement(By.xpath(TrainBotPageFactory.addButton)).click();
        }

    }

    public static void getWebElement(String xpath, boolean click) {
        boolean staleElement = true;
        while (staleElement) {
            try {
                if (click)
                    Utility.driver.findElement(By.xpath(xpath)).click();
                else
                    Utility.driver.findElement(By.xpath(xpath));
                staleElement = false;

            } catch (StaleElementReferenceException e) {
                staleElement = true;
            }
        }
    }

}
