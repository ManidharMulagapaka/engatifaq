package utilities;


import EnvSetters.HomeEnvSetter;
import com.sun.tools.internal.xjc.Driver;
import objectrepo.LoginPageFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class Utility {
    public static WebDriver driver;

    public static void setUp(){
        System.setProperty("webdriver.chrome.driver", "Driver/mac/chromedriver");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    public static void intialize(){
        setUp();
        driver.navigate().to(HomeEnvSetter.baseUrl);
        driver.findElement(By.xpath(LoginPageFactory.LoginUserNameTextBox)).click();
        driver.findElement(By.xpath(LoginPageFactory.LoginUserNameTextBox)).sendKeys(HomeEnvSetter.userName);
        driver.findElement(By.xpath(LoginPageFactory.LoginPasswordTextBox)).click();
        driver.findElement(By.xpath(LoginPageFactory.LoginPasswordTextBox)).sendKeys(HomeEnvSetter.password);
        driver.findElement(By.xpath(LoginPageFactory.LoginButton)).click();
    }

    public static void Destructing(){
        driver.quit();
    }
}



