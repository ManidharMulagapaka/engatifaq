package utilities;


import EnvSetters.HomeEnvSetter;
import objectrepo.LoginPageFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.io.IOException;
import java.sql.Driver;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Utility {

    public static WebDriver driver;
    static Logger logger = Logger.getLogger(Driver.class.getName());

    public static void setUp() {
        System.setProperty("webdriver.chrome.driver", "Driver/mac/chromedriver");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    public static void waitTillContetLoads(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @BeforeMethod
    public static void intialize() throws IOException, InterruptedException {
        setUp();
        HomeEnvSetter.setProperties();
        driver.navigate().to(HomeEnvSetter.baseUrl);
        logger.log(Level.INFO, "Driver launched successfully and moving to the Engati portal");
        waitTillContetLoads(2000);
        driver.navigate().refresh();
        driver.findElement(By.xpath(LoginPageFactory.loginUserNameTextBox)).click();
        driver.findElement(By.xpath(LoginPageFactory.loginUserNameTextBox)).sendKeys(HomeEnvSetter.userName);
        driver.findElement(By.xpath(LoginPageFactory.loginPasswordTextBox)).click();
        driver.findElement(By.xpath(LoginPageFactory.loginPasswordTextBox)).sendKeys(HomeEnvSetter.password);
        driver.findElement(By.xpath(LoginPageFactory.loginButton)).click();
        logger.log(Level.INFO, "logging in to the site");
        Thread.sleep(2000);
    }


    @AfterMethod
    public static void destructing() throws InterruptedException {
        Thread.sleep(3000);
        driver.quit();
        logger.log(Level.INFO, "Quitting the driver");
    }
}



