package utilities;


import EnvSetters.HomeEnvSetter;
import objectrepo.HistoryPageFactory;
import objectrepo.LoginPageFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Utility{
    public static WebDriver driver;


    public static void setUp(){
        System.setProperty("webdriver.chrome.driver", "Driver/mac/chromedriver");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    public static void waitTillContetLoads(int milliseconds){
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @BeforeMethod
    public static void intialize() throws IOException, InterruptedException {
        Thread.sleep(3000);
        setUp();
        HomeEnvSetter.intialize();
        driver.navigate().to(HomeEnvSetter.baseUrl);

        waitTillContetLoads(2000);

        driver.findElement(By.xpath(LoginPageFactory.LoginUserNameTextBox)).click();
        driver.findElement(By.xpath(LoginPageFactory.LoginUserNameTextBox)).sendKeys(HomeEnvSetter.userName);
        driver.findElement(By.xpath(LoginPageFactory.LoginPasswordTextBox)).click();
        driver.findElement(By.xpath(LoginPageFactory.LoginPasswordTextBox)).sendKeys(HomeEnvSetter.password);
        driver.findElement(By.xpath(LoginPageFactory.LoginButton)).click();
        Thread.sleep(3000);
    }



    @AfterMethod
    public static void destructing() throws InterruptedException {
        Thread.sleep(3000);
        driver.quit();
    }
}



