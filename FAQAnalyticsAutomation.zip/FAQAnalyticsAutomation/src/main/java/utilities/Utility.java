package utilities;

public class Utility {
}
