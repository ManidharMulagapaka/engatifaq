package EnvSetters;

public class InteractionsEnvSetter {
}
