package EnvSetters;


import org.openqa.selenium.By;
import utilities.Utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class InteractionsEnvSetter {
    public static String[] interactions = new String[10];
    public static void initialize() throws IOException {
        Utility.driver.findElement(By.xpath("//*[@id='menu']/ul/li[11]/a")).click();
        Properties properties = new Properties();
        FileInputStream file = new FileInputStream("/Users/kanimozhin/Downloads/FAQAnalyticsAutomation/src/main/resources/userinteractiontest.properties");
        properties.load(file);
        interactions = properties.getProperty("interactions").split("#");


}}
