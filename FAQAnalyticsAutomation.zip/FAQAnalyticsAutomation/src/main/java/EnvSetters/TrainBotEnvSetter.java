package EnvSetters;


import utilities.CommonFunctionalities;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Properties;
import java.util.Random;

public class TrainBotEnvSetter {
    public static String response;
    public static String[] questions;

    public static void setProperties() throws IOException {
        Properties properties = CommonFunctionalities.extractProperties("/Users/kanimozhin/Downloads/FAQAnalyticsAutomation/src/main/resources/trainbottest.properties");
        byte[] array = new byte[7];
        new Random().nextBytes(array);

        response = new String(array, Charset.forName("UTF-8"));
        questions = properties.getProperty("questions").split(",");

    }

}
