package EnvSetters;


import utilities.CommonFunctionalities;

import java.io.IOException;
import java.util.Properties;

public class TrainBotEnvSetter {
    public static String response;
    public static String[] questions;
    public static String botName;
    public static void setProperties() throws IOException {
       Properties properties = CommonFunctionalities.extractProperties("/Users/kanimozhin/Downloads/FAQAnalyticsAutomation/src/main/resources/trainbottest.properties");
       response = properties.getProperty("response");
       questions = properties.getProperty("questions").split(",");
       botName = properties.getProperty("botName");
    }

}
