package EnvSetters;

import utilities.CommonFunctionalities;

import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

public class HistoryEnvSetter {
    public static String[] entries;
    public static int totalCount;
    public static String[] pagesCount;
    public static String[] lastActiveFilter;
    public static String[] responseFoundFilter;
    public static String[] responseHelpfulFilter;
    public static String joiningDateOfUser;
    public static String[] lastActiveWithOutput;
    public static String[] lastActiveWithOutOutput;
    static public String[] buildRequest = new String[5];
    static public String[] Response = new String[5];
    static public String[] partialRequest = new String[5];
    static public String validSearch;
    public static String invalidSearch;
    public static String noResultPageMsg;
    public static String actualDefaultMessage;
    public static String actualScore;
    public static HashMap<String, String> correct = new HashMap<>();
    public static HashMap<String, String> partial = new HashMap<String, String>();

    public static void historyProperties() throws IOException {
        Properties properties = CommonFunctionalities.extractProperties("/Users/kanimozhin/Downloads/FAQAnalyticsAutomation/src/main/resources/historytest.properties");
        entries = properties.getProperty("entry").split(",");
        totalCount = Integer.parseInt(properties.getProperty("totalEntries"));
        pagesCount = properties.getProperty("pagesCount").split(",");
        lastActiveFilter = properties.getProperty("lastActive").split(",");
        responseFoundFilter = properties.getProperty("responseFound").split(",");
        responseHelpfulFilter = properties.getProperty("responseHelpful").split(",");
        joiningDateOfUser = properties.getProperty("JoiningDateOfUser");
        lastActiveWithOutput = properties.getProperty("lastActiveOutput").split(",");
        lastActiveWithOutOutput = properties.getProperty("lastActiveNoOutput").split(",");
        buildRequest = properties.getProperty("buildrequest").split(",");
        Response = properties.getProperty("response").split(",");
        partialRequest = properties.getProperty("partialrequest").split(",");
        entries = properties.getProperty("entry").split(",");
        for (int i = 0; i < buildRequest.length; i++) {
            correct.put(Response[i], buildRequest[i]);
            partial.put(Response[i], partialRequest[i]);
        }
        noResultPageMsg = properties.getProperty("messageOfNoResultPage");
        actualDefaultMessage = properties.getProperty("actualDefaultMessage");
        actualScore = properties.getProperty("Actualscore");
        properties = CommonFunctionalities.extractProperties("/Users/kanimozhin/Downloads/FAQAnalyticsAutomation/src/main/resources/searchtest.properties");
        validSearch = properties.getProperty("ValidSearch");
        invalidSearch = properties.getProperty("InValidSearch");

    }

}
