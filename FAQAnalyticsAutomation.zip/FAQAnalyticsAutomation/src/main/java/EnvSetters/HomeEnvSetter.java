package EnvSetters;

import org.testng.annotations.BeforeClass;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class HomeEnvSetter {
    public static String baseUrl;
    public static String userName;
    public static String password;

    @BeforeClass
    public static void setProperties() throws IOException {
        Properties properties = new Properties();
        FileInputStream file = new FileInputStream("/Users/kanimozhin/Downloads/FAQAnalyticsAutomation/src/main/resources/login.properties");
        properties.load(file);
        baseUrl = properties.getProperty("BaseUrl");
        userName = properties.getProperty("Username");
        password = properties.getProperty("Password");
    }
}
