package implementations;
import EnvSetters.HistoryEnvSetter;
import org.openqa.selenium.StaleElementReferenceException;
import org.testng.Assert;
import org.testng.TestNGAntTask.Mode.*;
import objectrepo.HistoryPageFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import utilities.Utility;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static java.util.Objects.isNull;

public class FAQHistorySearch {


    static public void sortingAndVerifyingScore(){
        boolean state = true;
        while(state){
           try{
               Utility.driver.findElement(By.xpath(HistoryPageFactory.sortScore)).click();
               state = false;
           }
           catch (StaleElementReferenceException e)
           {
               state = true;
           }
        }

        double previous = 0.0d ;
        double current = 0.0d ;
        String temp;
        for(int i=2;i<5;i++){
            temp = Utility.driver.findElement(By.xpath(HistoryPageFactory.Score.replace("%s",new Integer(i-1).toString()))).getText();
            if(temp.equals(""))
                previous = 0.0d;
            else
                previous = Float.parseFloat(temp);
            temp = Utility.driver.findElement(By.xpath(HistoryPageFactory.Score.replace("%s",new Integer(i).toString()))).getText();
            if(temp.equals(""))
                current = 0.0d;
            else
                current = Float.parseFloat(temp);
            Assert.assertTrue(current >= previous, "Sorting is not Valid");
        }

        Utility.driver.findElement(By.xpath(HistoryPageFactory.sortScore)).click();
        previous = 0.0d ;
        current = 0.0d ;
        for(int i=2;i<5;i++){
            temp = Utility.driver.findElement(By.xpath(HistoryPageFactory.Score.replace("%s",new Integer(i-1).toString()))).getText();
            if(temp.equals(""))
                previous = 0.0d;
            else
                previous = Float.parseFloat(temp);
            temp = Utility.driver.findElement(By.xpath(HistoryPageFactory.Score.replace("%s",new Integer(i).toString()))).getText();
            if(temp.equals(""))
                current = 0.0d;
            else
                current = Float.parseFloat(temp);
            Assert.assertTrue(current <= previous,"Sorting is not Valid");
        }
    }

    static public void sortingAndVerifyingDate() throws ParseException {
        Utility.driver.findElement(By.xpath(HistoryPageFactory.sortDate)).click();
        SimpleDateFormat simpleDateFormatPrevious = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat simpleDateFormatCurrent = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String temp="";
        for(int i=2;i<5;i++) {
            temp = Utility.driver.findElement(By.xpath(HistoryPageFactory.Date.replace("%s",new Integer(i-1).toString()))).getText();
            Date previousDate = simpleDateFormatPrevious.parse(temp);
            temp = Utility.driver.findElement(By.xpath(HistoryPageFactory.Date.replace("%s",new Integer(i).toString()))).getText();
            Date currentDate = simpleDateFormatCurrent.parse(temp);
            if(previousDate.compareTo(currentDate) > 0)
            {

            }
        }
        Utility.driver.findElement(By.xpath(HistoryPageFactory.sortDate)).click();
        for(int i=2;i<5;i++) {
            temp = Utility.driver.findElement(By.xpath(HistoryPageFactory.Date.replace("%s",new Integer(i-1).toString()))).getText();
            Date previousDate = simpleDateFormatPrevious.parse(temp);
            temp = Utility.driver.findElement(By.xpath(HistoryPageFactory.Date.replace("%s",new Integer(i).toString()))).getText();
            Date currentDate = simpleDateFormatCurrent.parse(temp);
            if(previousDate.compareTo(currentDate) < 0)
            {

            }
        }
    }

    static public void searchingForAWordInSearch(String searchValue) throws IOException, InterruptedException {
        Utility.driver.findElement(By.xpath(HistoryPageFactory.searchBox)).sendKeys(searchValue);
        Utility.driver.findElement(By.xpath(HistoryPageFactory.searchButton)).click();

        WebElement entriesTab = Utility.driver.findElement(By.xpath(HistoryPageFactory.entriesSelect));
        Select entriesSelectTab = new Select(entriesTab);
        int count = 1;

        String questioned,matched,result;
        JavascriptExecutor executor = (JavascriptExecutor) Utility.driver;
        executor.executeScript("window.scrollBy[0,1000]");


            for (int i = 1; i <= 10; i++) {
                Thread.sleep(2000);
                questioned = Utility.driver.findElement(By.xpath(HistoryPageFactory.requests.replace("%s", new Integer(i).toString()))).getText();

                matched = Utility.driver.findElement(By.xpath(HistoryPageFactory.partial.replace("%s",new Integer(i).toString()))).getText();

                result = Utility.driver.findElement(By.xpath(HistoryPageFactory.answers.replace("%s",new Integer(i).toString()))).getText();


                Assert.assertTrue((questioned.contains(searchValue) || matched.contains(searchValue) || result.contains(searchValue)),"Search is not working");
            }
            FAQHistory.checkFaqPaginations();
        }



    static public void searchingForAInValidRecordInHistory(String searchValue){
        Utility.driver.findElement(By.xpath(HistoryPageFactory.searchBox)).sendKeys(searchValue);
        Utility.driver.findElement(By.xpath(HistoryPageFactory.searchButton)).click();

        WebElement entriesTab = Utility.driver.findElement(By.xpath(HistoryPageFactory.entriesSelect));
        Select entriesSelectTab = new Select(entriesTab);
        int count = 1;

        boolean state = true;
        while (state){
            try{
                Utility.driver.findElement(By.xpath(HistoryPageFactory.NOResults));
                state = false;
            }
            catch(StaleElementReferenceException e){
                state = true;
            }
        }

        Assert.assertTrue(Utility.driver.findElement(By.xpath(HistoryPageFactory.NOResults)).isDisplayed(),"The Result are being displayed");

    }

    public static void verifyingCSVButton(String searchValue){
        Utility.driver.findElement(By.xpath(HistoryPageFactory.searchBox)).sendKeys(searchValue);
        Utility.driver.findElement(By.xpath(HistoryPageFactory.searchButton)).click();
        Utility.waitTillContetLoads(1000);
        int size=0;
        try {
            Utility.driver.findElements(By.xpath(HistoryPageFactory.ExportCSV));
        }
        catch(Exception e){
            size=0;
        }
        Assert.assertTrue(size == 0 ,"The csv button should be disabled");

    }
}



