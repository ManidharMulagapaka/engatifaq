package implementations;

public class FAQHistorySearch {
}
