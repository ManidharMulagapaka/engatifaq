package implementations;


import objectrepo.HistoryPageFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import utilities.CommonFunctionalities;
import utilities.Utility;
import java.io.IOException;
import java.sql.Driver;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;


public class FAQHistorySearch {

    static Logger logger = Logger.getLogger(Driver.class.getName());


    static public void sortingAndVerifyingScore() {
        logger.log(Level.INFO, "Sorting the search result and verifying the Score");


        try {
            Utility.driver.findElement(By.xpath(HistoryPageFactory.sortScore)).click();

        } catch (StaleElementReferenceException e) {
            CommonFunctionalities.getWebElement(HistoryPageFactory.sortScore, true);
        }


        double previous = 0.0d;
        double current = 0.0d;
        String temp;
        for (int i = 2; i < 5; i++) {
            temp = Utility.driver.findElement(By.xpath(HistoryPageFactory.Score.replace("%s", new Integer(i - 1).toString()))).getText();
            if (temp.equals(""))
                previous = 0.0d;
            else
                previous = Float.parseFloat(temp);
            temp = Utility.driver.findElement(By.xpath(HistoryPageFactory.Score.replace("%s", new Integer(i).toString()))).getText();
            if (temp.equals(""))
                current = 0.0d;
            else
                current = Float.parseFloat(temp);
            Assert.assertTrue(current >= previous, "Sorting by score is not Valid");
        }

        Utility.driver.findElement(By.xpath(HistoryPageFactory.sortScore)).click();
        previous = 0.0d;
        current = 0.0d;
        for (int i = 2; i < 5; i++) {
            temp = Utility.driver.findElement(By.xpath(HistoryPageFactory.Score.replace("%s", new Integer(i - 1).toString()))).getText();
            if (temp.equals(""))
                previous = 0.0d;
            else
                previous = Float.parseFloat(temp);
            temp = Utility.driver.findElement(By.xpath(HistoryPageFactory.Score.replace("%s", new Integer(i).toString()))).getText();
            if (temp.equals(""))
                current = 0.0d;
            else
                current = Float.parseFloat(temp);
            Assert.assertTrue(current <= previous, "Sorting by score is not Valid");
        }
    }

    static public void sortingAndVerifyingDate() throws ParseException {
        logger.log(Level.INFO, "Sorting search result based on date and time");
        Utility.driver.findElement(By.xpath(HistoryPageFactory.sortDate)).click();
        SimpleDateFormat simpleDateFormatPrevious = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat simpleDateFormatCurrent = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String temp = "";
        for (int i = 2; i < 5; i++) {
            temp = Utility.driver.findElement(By.xpath(HistoryPageFactory.date.replace("%s", new Integer(i - 1).toString()))).getText();
            Date previousDate = simpleDateFormatPrevious.parse(temp);
            temp = Utility.driver.findElement(By.xpath(HistoryPageFactory.date.replace("%s", new Integer(i).toString()))).getText();
            Date currentDate = simpleDateFormatCurrent.parse(temp);
            Assert.assertTrue((previousDate.compareTo(currentDate) <= 0), "Sorting by date is not Valid");
        }
        Utility.driver.findElement(By.xpath(HistoryPageFactory.sortDate)).click();
        for (int i = 2; i < 5; i++) {
            temp = Utility.driver.findElement(By.xpath(HistoryPageFactory.date.replace("%s", new Integer(i - 1).toString()))).getText();
            Date previousDate = simpleDateFormatPrevious.parse(temp);
            temp = Utility.driver.findElement(By.xpath(HistoryPageFactory.date.replace("%s", new Integer(i).toString()))).getText();
            Date currentDate = simpleDateFormatCurrent.parse(temp);
            Assert.assertTrue((previousDate.compareTo(currentDate) >= 0), "Sorting by date is not Valid");
        }
    }

    static public void searchingForAWordInSearch(String searchValue) throws IOException, InterruptedException {
        logger.log(Level.INFO, "Searching for a valid record with search value  : " + searchValue);
        Utility.driver.findElement(By.xpath(HistoryPageFactory.searchBox)).sendKeys(searchValue);
        Utility.driver.findElement(By.xpath(HistoryPageFactory.searchButton)).click();

        WebElement entriesTab = Utility.driver.findElement(By.xpath(HistoryPageFactory.entriesSelect));
        Select entriesSelectTab = new Select(entriesTab);
        int count = 1;

        String questioned, matched, result;
        JavascriptExecutor executor = (JavascriptExecutor) Utility.driver;
        executor.executeScript("window.scrollBy[0,1000]");


        for (int i = 1; i <= 10; i++) {
            Thread.sleep(2000);
            questioned = Utility.driver.findElement(By.xpath(HistoryPageFactory.requests.replace("%s", new Integer(i).toString()))).getText();

            matched = Utility.driver.findElement(By.xpath(HistoryPageFactory.partial.replace("%s", new Integer(i).toString()))).getText();

            result = Utility.driver.findElement(By.xpath(HistoryPageFactory.answers.replace("%s", new Integer(i).toString()))).getText();


            Assert.assertTrue((questioned.contains(searchValue) || matched.contains(searchValue) || result.contains(searchValue)), "Search is not working for valid search string");
        }
        FAQHistory.checkFaqPaginations();
    }


    static public void searchingForAInValidRecordInHistory(String searchValue) {
        logger.log(Level.INFO, "Searching for invalid record with search value :  " + searchValue);
        WebDriverWait wait = new WebDriverWait(Utility.driver, 60);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(HistoryPageFactory.searchBox)));

        Utility.driver.findElement(By.xpath(HistoryPageFactory.searchBox)).sendKeys(searchValue);
        Utility.driver.findElement(By.xpath(HistoryPageFactory.searchButton)).click();

        WebElement entriesTab = Utility.driver.findElement(By.xpath(HistoryPageFactory.entriesSelect));
        Select entriesSelectTab = new Select(entriesTab);
        int count = 1;


        try {
            Utility.driver.findElement(By.xpath(HistoryPageFactory.nOResults)).isDisplayed();

        } catch (StaleElementReferenceException e) {
            CommonFunctionalities.getWebElement(HistoryPageFactory.nOResults, false);
        }


        Assert.assertTrue(Utility.driver.findElement(By.xpath(HistoryPageFactory.nOResults)).isDisplayed(), "The Result are being displayed for non existing search string");

    }

    public static void verifyingCSVButton(String searchValue) {
        logger.log(Level.INFO, "verifying Export CSV Button ");
        Utility.driver.findElement(By.xpath(HistoryPageFactory.searchBox)).sendKeys(searchValue);
        Utility.driver.findElement(By.xpath(HistoryPageFactory.searchButton)).click();
        Utility.waitTillContetLoads(1000);
        int size = 0;
        try {
            Utility.driver.findElements(By.xpath(HistoryPageFactory.exportCSV));
        } catch (Exception e) {
            size = 0;
        }
        Assert.assertTrue(size == 0, "The csv button should be disabled for empty search results");

    }
}



