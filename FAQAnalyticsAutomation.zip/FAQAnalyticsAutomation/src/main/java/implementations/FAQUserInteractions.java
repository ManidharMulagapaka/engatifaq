package implementations;

import EnvSetters.InteractionsEnvSetter;
import objectrepo.HistoryPageFactory;
import objectrepo.InteractionsPageFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.testng.Assert;
import utilities.Utility;

public class FAQUserInteractions {
    public static void checkingUserInformation(){
        Utility.driver.findElement(By.xpath(HistoryPageFactory.sortDate));
        Utility.driver.findElement(By.xpath(HistoryPageFactory.sortDate));
        Utility.driver.findElement(By.xpath(InteractionsPageFactory.SelectingTopRow)).click();
        String userName = Utility.driver.findElement(By.xpath(InteractionsPageFactory.UserName)).getText();
        String dateJoined  = Utility.driver.findElement(By.xpath(InteractionsPageFactory.DateAcquired)).getText();
        Assert.assertEquals(userName,"Website User","Username is wrong");
        Assert.assertEquals(dateJoined,"2019-01-28", "Datejoined is wrong");


    }

    public static void checkingUserInteractions(){

        Utility.driver.findElement(By.xpath(HistoryPageFactory.sortDate));
        boolean state = true;
        while (state){
        try{
        Utility.driver.findElement(By.xpath(InteractionsPageFactory.SelectingTopRow)).click();
            state=false;}
        catch (StaleElementReferenceException e){
            state = true;

        }}
        String actual = "";
        String expected = "";
        int index=0;
        for(int i=1; i <= InteractionsEnvSetter.interactions.length ; i++ ){
            expected = InteractionsEnvSetter.interactions[index++];
            actual = Utility.driver.findElement(By.xpath(InteractionsPageFactory.Messages.replace("%s",new Integer(i).toString()))).getText();
            Assert.assertEquals(actual,expected,"The user interactions are not matching");
        }
        Assert.assertEquals(3,Integer.parseInt(Utility.driver.findElement(By.xpath("//*[@class='userDetailMetrics']/label[@ng-model='no_of_conversations_for_user']")).getText()));




    }
}
