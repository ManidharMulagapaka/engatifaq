package implementations;

import EnvSetters.InteractionsEnvSetter;
import objectrepo.HistoryPageFactory;
import objectrepo.InteractionsPageFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.testng.Assert;
import utilities.CommonFunctionalities;
import utilities.Utility;

import java.sql.Driver;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FAQUserInteractions {

    static Logger logger = Logger.getLogger(Driver.class.getName());

    public static void checkingUserInformation() {
        logger.log(Level.INFO, "Checking the information of bot user");
        Utility.driver.findElement(By.xpath(HistoryPageFactory.sortDate));
        Utility.driver.findElement(By.xpath(HistoryPageFactory.sortDate));
        Utility.driver.findElement(By.xpath(InteractionsPageFactory.selectingTopRow)).click();
        String userName = Utility.driver.findElement(By.xpath(InteractionsPageFactory.userName)).getText();
        String dateJoined = Utility.driver.findElement(By.xpath(InteractionsPageFactory.dateAcquired)).getText();
        Assert.assertEquals(userName, "Website User", "Username is displayed incorrectly");
        Assert.assertEquals(dateJoined, "2019-01-28", "Displaying incorrect Date of Joining");


    }

    public static void checkingUserInteractions() {

        logger.log(Level.INFO, "Validating the interactions between the bot and the user");

        Utility.driver.findElement(By.xpath(HistoryPageFactory.sortDate));


        try {
            Utility.driver.findElement(By.xpath(InteractionsPageFactory.selectingTopRow)).click();

        } catch (StaleElementReferenceException e) {
            CommonFunctionalities.getWebElement(InteractionsPageFactory.selectingTopRow, true);

        }

        String actual = "";
        String expected = "";
        int index = 0;
        for (int i = 1; i <= InteractionsEnvSetter.interactions.length; i++) {
            expected = InteractionsEnvSetter.interactions[index++];
            actual = Utility.driver.findElement(By.xpath(InteractionsPageFactory.messages.replace("%s", new Integer(i).toString()))).getText();
            Assert.assertEquals(actual, expected, "The user interactions are not matching");
        }
        Assert.assertEquals(3, Integer.parseInt(Utility.driver.findElement(By.xpath("//*[@class='userDetailMetrics']/label[@ng-model='no_of_conversations_for_user']")).getText()));


    }
}
