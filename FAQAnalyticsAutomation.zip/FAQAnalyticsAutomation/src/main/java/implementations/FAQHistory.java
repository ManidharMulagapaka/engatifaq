package implementations;

import EnvSetters.HistoryEnvSetter;
import objectrepo.HistoryPageFactory;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import utilities.CommonFunctionalities;
import utilities.Utility;
import java.sql.Driver;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import static java.time.temporal.ChronoUnit.DAYS;
import static java.util.Objects.isNull;

public class FAQHistory {
    static Logger logger = Logger.getLogger(Driver.class.getName());

    static public void verifyingHistoryDetails() {
        logger.log(Level.INFO, "Verifying chat details with question, response and score");
        String logMessage = "";
        for (int i = 1; i <= 5; i++) {
            Utility.waitTillContetLoads(1000);
            String answer = Utility.driver.findElement(By.xpath(HistoryPageFactory.answers.replace("%s", new Integer(i).toString()))).getAttribute("title");
            String question = Utility.driver.findElement(By.xpath(HistoryPageFactory.requests.replace("%s", new Integer(i).toString()))).getText();

            if (!isNull(HistoryEnvSetter.correct.get(answer))) {
                if (HistoryEnvSetter.correct.get(answer).equals(question)) {
                    String accuracy = Utility.driver.findElement(By.xpath(HistoryPageFactory.accuracy.replace("%s", Integer.toString(i)))).getText();
                    logMessage += "Response :" + answer + "  " + "Question Asked +" + HistoryEnvSetter.correct.get(answer) + " Score :" + accuracy + "\n";
                    Assert.assertTrue(accuracy.equals(HistoryEnvSetter.actualScore), "Proper Response for the query but the accuracy is wrong");
                } else if (HistoryEnvSetter.partial.get(answer).equals(question)) {
                    String accuracy = Utility.driver.findElement(By.xpath(HistoryPageFactory.accuracy.replace("%s", Integer.toString(i)))).getText();
                    logMessage += "Response :" + answer + "  " + "Question Asked +" + HistoryEnvSetter.partial.get(answer) + " Score :" + accuracy + "\n";
                    Assert.assertTrue(!accuracy.equals(HistoryEnvSetter.actualScore), "Proper Response for the query but the accuracy is wrong");
                }
            } else {
                String accuracy = Utility.driver.findElement(By.xpath(HistoryPageFactory.accuracy.replace("%s", Integer.toString(i)))).getText();
                logMessage += " Question Asked " + question;
                // Assert.assertTrue(accuracy.isEmpty(), "Non built query accuracy is wrong");
            }
        }
        logger.log(Level.INFO, "Looping through records :" + logMessage);
    }


    public static void checkFaqPaginations() throws InterruptedException {

        logger.log(Level.INFO, "Checking Pagination of FAQ History Page ");
        WebElement entriesTab = Utility.driver.findElement(By.xpath(HistoryPageFactory.entriesSelect));
        Select entriesSelectTab = new Select(entriesTab);
        for (String entry : HistoryEnvSetter.entries) {
            entriesSelectTab.selectByValue(entry);
            WebElement nextButton = Utility.driver.findElement(By.xpath("(" + HistoryPageFactory.pageDivision + ")[last()]/a"));
            boolean state = true;
            while (state) {
                nextButton.click();
                Thread.sleep(1000);
                List<WebElement> faqHistoriesList = Utility.driver.findElements(By.xpath(HistoryPageFactory.faqHistoriesList));
                Assert.assertTrue(!((faqHistoriesList.size() != Integer.parseInt(entry)) && Utility.driver.findElement(By.xpath("(" + HistoryPageFactory.pageDivision + ")[last()]/a")).getAttribute("disabled") == null), "Number of histories is not equal to the entry");
                if (Utility.driver.findElement(By.xpath("(" + HistoryPageFactory.pageDivision + ")[last()]/a")).getAttribute("disabled") != null)
                    state = false;
            }
        }


    }

    public static void faqFilters(String lastActive, String responseFound, String responseHelpful) throws InterruptedException, ParseException {

        logger.log(Level.INFO, "Validating Filters ");
        logger.log(Level.INFO, "Last Active : " + lastActive + " Response Found :" + responseFound + "Response Helpful :" + responseHelpful);
        if (lastActive.equals("All")) {
            Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActiveFilter)).click();
            Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActivedropdownAny)).click();

            CommonFunctionalities.selectFilters(responseFound);
            Utility.driver.findElement(By.xpath(HistoryPageFactory.applyButton)).click();
            Thread.sleep(3000);


            for (int i = 1; i <= 3; i++) {

                String[] strDate = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryDateTime)).getText().split(" ");
                Date joiningDate = new SimpleDateFormat("dd/MM/yyyy").parse(HistoryEnvSetter.joiningDateOfUser);
                Date historyDate = new SimpleDateFormat("yyyy-MM-dd").parse(strDate[0]);
                logger.log(Level.INFO, "Comparing Joining Date:" + joiningDate + " and History Date :" + historyDate);
                Assert.assertTrue((historyDate.compareTo(joiningDate) >= 0), "Filtering failed");
            }

        } else if (lastActive.equals("Last 24 hours")) {
            Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActiveFilter)).click();
            Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActiveFilter24Hours)).click();
            logger.log(Level.INFO, "Checking whether the date is with in 24 hours ");
            CommonFunctionalities.selectFilters(responseFound);
            Utility.driver.findElement(By.xpath(HistoryPageFactory.applyButton)).click();
            Thread.sleep(3000);


            for (int i = 1; i <= 3; i++
                    ) {

                String strDate = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryDateTime)).getText();
                DateTime dateTimeBefore24Hours = DateTime.now().minusHours(24);
                DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
                DateTime historyDateTime = formatter.parseDateTime(strDate);

                Assert.assertTrue(historyDateTime.isAfter(dateTimeBefore24Hours), "Filtering histories beyond last 24 hours");
            }
        } else if (lastActive.equals("Last 7 days")) {
            Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActiveFilter)).click();
            Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActiveFilter7days)).click();
            CommonFunctionalities.selectFilters(responseFound);
            Utility.driver.findElement(By.xpath(HistoryPageFactory.applyButton)).click();
            Thread.sleep(3000);
            logger.log(Level.INFO, "Checking whether the date is with in last 7 days ");
            for (int i = 1; i <= 3; i++
                    ) {
                String[] strDate = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryDateTime)).getText().split(" ");
                LocalDate currentDate = LocalDate.now();
                LocalDate historyDate = new SimpleDateFormat("yyyy-MM-dd").parse(strDate[0]).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                long daysBetween = DAYS.between(historyDate, currentDate);
                Assert.assertTrue(daysBetween <= 7, "Filtering histories beyond last 7 days");

            }
        } else {
            Date startDate = null;
            Date endDate = null;
            Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActiveFilter)).click();
            String[] lastActiveDates = lastActive.split("-");
            Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActiveFilterFromDate)).clear();
            Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActiveFilterFromDate)).sendKeys(lastActiveDates[0]);
            Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActiveFilterToDate)).clear();
            Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActiveFilterToDate)).sendKeys(lastActiveDates[1]);
            Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActiveFilterApply)).click();
            CommonFunctionalities.selectFilters(responseFound);
            Utility.driver.findElement(By.xpath(HistoryPageFactory.applyButton)).click();

            if (lastActiveDates[0].contains(" ")) {
                startDate = new SimpleDateFormat("MMM dd yyyy").parse(lastActiveDates[0]);
                endDate = new SimpleDateFormat("MMM dd yyyy").parse(lastActiveDates[1]);
            } else if (lastActiveDates[0].contains("/")) {
                startDate = new SimpleDateFormat("dd/MM/yyyy").parse(lastActiveDates[0]);
                endDate = new SimpleDateFormat("dd/MM/yyyy").parse(lastActiveDates[1]);
            }

            for (int i = 1; i <= 3; i++
                    ) {
                String[] strDate = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryDateTime)).getText().split(" ");
                Date historyDate = new SimpleDateFormat("yyyy-MM-dd").parse(strDate[0]);

                Assert.assertTrue(((startDate.compareTo(historyDate) * historyDate.compareTo(endDate)) >= 0), "Filtering histories beyond the range of dates");

            }


        }


    }

    public static void faqFailFilters(String lastActive) {
        logger.log(Level.INFO, "Checking with random values");

        Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActiveFilter)).click();
        String[] lastActiveDates = lastActive.split("-");
        Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActiveFilterFromDate)).clear();
        Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActiveFilterFromDate)).sendKeys(lastActiveDates[0]);
        Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActiveFilterToDate)).clear();
        Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActiveFilterToDate)).sendKeys(lastActiveDates[1]);
        Utility.driver.findElement(By.xpath(HistoryPageFactory.lastActiveFilterApply)).click();
        Utility.driver.findElement(By.xpath(HistoryPageFactory.applyButton)).click();
        WebElement faqHistories = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList));
        Assert.assertTrue(faqHistories.findElement(By.xpath(HistoryPageFactory.failFilteringsubXpath)).getText().equals(HistoryEnvSetter.noResultPageMsg), "Failed, filtering histories for invalid date values");
    }

    public static void chatBotWithoutInitalzation() {
        Utility.waitTillContetLoads(1000);
        Assert.assertEquals(((Utility.driver.findElement(By.xpath(HistoryPageFactory.defaultMessage))).getText()), (HistoryEnvSetter.actualDefaultMessage), "The Default message is not shown");
    }

    public static void chatBotWithInitalzation() {
        Utility.waitTillContetLoads(1000);
        Assert.assertEquals(((Utility.driver.findElement(By.xpath(HistoryPageFactory.nOResults))).getText()), (HistoryEnvSetter.noResultPageMsg), "The Default message is not shown");
    }


}
