package implementations;

public class FAQHistory {
}
