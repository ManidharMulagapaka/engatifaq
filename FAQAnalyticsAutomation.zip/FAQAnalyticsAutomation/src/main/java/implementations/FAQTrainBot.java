package implementations;

import objectrepo.HistoryPageFactory;
import objectrepo.TrainBotPageFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import utilities.CommonFunctionalities;
import utilities.Utility;
import java.sql.Driver;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import static java.util.Objects.isNull;

public class FAQTrainBot {

    static Logger logger = Logger.getLogger(Driver.class.getName());

    public static void existingFaqTrainWithResponse(String response) throws InterruptedException {
        logger.log(Level.INFO, "Training the bot by updating response of built FAQ questions");
        String answer = null;
        WebElement trainButton = null;
        int i = 1;
        List<WebElement> faqHistoriesList = Utility.driver.findElements(By.xpath(HistoryPageFactory.faqHistoriesList));
        for (i = 1; i <= faqHistoriesList.size(); i++
                ) {

            trainButton = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryTrain));
            answer = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryAnswer)).getAttribute("title");
            if (answer.equals("Fallback Msg Shown") == false)
                break;
        }
        String previousResponse = "";

        CommonFunctionalities.trainBot(trainButton, null, response);
        previousResponse = Utility.driver.findElement(By.xpath(TrainBotPageFactory.tarinBotResponse)).getText();
        Thread.sleep(4000);
        Utility.driver.navigate().refresh();


        try {
            Utility.driver.findElement(By.xpath("(" + HistoryPageFactory.faqHistoryTrainButton + ")[" + i + "]")).click();
        } catch (StaleElementReferenceException e) {
            CommonFunctionalities.getWebElement("(" + HistoryPageFactory.faqHistoryTrainButton + ")[" + i + "]", true);
        }
        Thread.sleep(3000);
        String updatedResponse = null;
        while (isNull(updatedResponse)) {
            updatedResponse = Utility.driver.findElement(By.xpath(TrainBotPageFactory.tarinBotResponse)).getText();
        }
        logger.log(Level.INFO, "checking whether the response is updated");
        org.testng.Assert.assertFalse(updatedResponse.equals(previousResponse), "Response is not getting updated");


    }

    public static void existingFaqTrainWithQuestionAndResponse(String[] questions, String response) throws InterruptedException {
        logger.log(Level.INFO, "Training the bot by updating response and adding question of built FAQ questions");
        String answer = null;
        WebElement trainButton = null;
        int i = 1;
        List<WebElement> faqHistoriesList = Utility.driver.findElements(By.xpath(HistoryPageFactory.faqHistoriesList));
        for (i = 1; i <= faqHistoriesList.size(); i++
                ) {

            trainButton = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryTrain));
            answer = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryAnswer)).getAttribute("title");
            if (answer.equals("Fallback Msg Shown") == false)
                break;
        }
        String previousResponse = "";

        CommonFunctionalities.trainBot(trainButton, questions, response);
        previousResponse = Utility.driver.findElement(By.xpath(TrainBotPageFactory.tarinBotResponse)).getText();
        Thread.sleep(5000);


        try {
            Utility.driver.findElement(By.xpath("(" + HistoryPageFactory.faqHistoryTrainButton + ")[" + i + "]")).click();
        } catch (StaleElementReferenceException e) {
            CommonFunctionalities.getWebElement("(" + HistoryPageFactory.faqHistoryTrainButton + ")[" + i + "]", true);
        }
        Thread.sleep(3000);
        String updatedResponse = "";
        List<WebElement> responseList = Utility.driver.findElements(By.xpath(TrainBotPageFactory.tarinBotResponse));
        if (responseList.size() > 1)
            updatedResponse = Utility.driver.findElement(By.xpath(TrainBotPageFactory.tarinBotResponse + "[" + responseList.size() + "]")).getText();
        else updatedResponse = Utility.driver.findElement(By.xpath(TrainBotPageFactory.tarinBotResponse)).getText();
        logger.log(Level.INFO, "checking whether the response is updated");
        Assert.assertFalse(updatedResponse.equals(previousResponse), "Response is not getting updated");


    }

    public static void nonExistingFaqTrainWithResponse(String response) throws InterruptedException {
        logger.log(Level.INFO, "Training the bot by updating response of random FAQ questions");
        String answer = null;
        WebElement trainButton = null;
        int i = 1;
        List<WebElement> faqHistoriesList = Utility.driver.findElements(By.xpath(HistoryPageFactory.faqHistoriesList));
        for (i = 1; i <= faqHistoriesList.size(); i++
                ) {

            trainButton = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryTrain));
            answer = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryAnswer)).getAttribute("title");
            if (answer.equals("Fallback Msg Shown"))
                break;
        }
        String previousResponse = "";

        CommonFunctionalities.trainBot(trainButton, null, response);
        Thread.sleep(5000);

        try {
            Utility.driver.findElement(By.xpath("(" + HistoryPageFactory.faqHistoryTrainButton + ")[" + i + "]")).click();
        } catch (StaleElementReferenceException e) {
            CommonFunctionalities.getWebElement("(" + HistoryPageFactory.faqHistoryTrainButton + ")[" + i + "]", true);
        }
        Thread.sleep(3000);
        String updatedResponse = Utility.driver.findElement(By.xpath(TrainBotPageFactory.tarinBotResponse)).getText();
        logger.log(Level.INFO, "checking whether the response is updated");
        Assert.assertFalse(updatedResponse.equals(previousResponse), "Response is not getting updated");


    }

    public static void nonExistingFaqTrainWithQuestionAndResponse(String[] questions, String response) throws InterruptedException {
        logger.log(Level.INFO, "Training the bot by updating response and adding question of random FAQ questions");
        String answer = null;
        WebElement trainButton = null;
        int i = 1;
        List<WebElement> faqHistoriesList = Utility.driver.findElements(By.xpath(HistoryPageFactory.faqHistoriesList));
        for (i = 1; i <= faqHistoriesList.size(); i++
                ) {

            trainButton = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryTrain));
            answer = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryAnswer)).getAttribute("title");
            if (answer.equals("Fallback Msg Shown"))
                break;
        }
        String previousResponse = "";

        CommonFunctionalities.trainBot(trainButton, questions, response);
        Thread.sleep(5000);

        try {
            Utility.driver.findElement(By.xpath("(" + HistoryPageFactory.faqHistoryTrainButton + ")[" + i + "]")).click();
        } catch (StaleElementReferenceException e) {
            CommonFunctionalities.getWebElement("(" + HistoryPageFactory.faqHistoryTrainButton + ")[" + i + "]", true);
        }

        Thread.sleep(3000);
        String updatedResponse = "";
        List<WebElement> responseList = Utility.driver.findElements(By.xpath(TrainBotPageFactory.tarinBotResponse));
        if (responseList.size() > 1)
            updatedResponse = Utility.driver.findElement(By.xpath(TrainBotPageFactory.tarinBotResponse + "[" + responseList.size() + "]")).getText();
        else updatedResponse = Utility.driver.findElement(By.xpath(TrainBotPageFactory.tarinBotResponse)).getText();
        logger.log(Level.INFO, "checking whether the response is updated");
        Assert.assertFalse(updatedResponse.equals(previousResponse), "Response is not getting updated");

    }



    }
