package implementations;


import objectrepo.HistoryPageFactory;
import objectrepo.TrainBotPageFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.testng.Assert;
import utilities.CommonFunctionalities;
import utilities.Utility;

import java.util.List;

import static EnvSetters.TrainBotEnvSetter.questions;
import static java.util.Objects.isNull;

public class FAQTrainBot {

    public static void existingFaqTrainWithResponse(String response) throws InterruptedException {
        String answer=null;
        WebElement trainButton =null;
        int i = 1;
        List<WebElement> faqHistoriesList = Utility.driver.findElements(By.xpath(HistoryPageFactory.faqHistoriesList));
        for ( i = 1; i <= faqHistoriesList.size(); i++
                ) {

            trainButton = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryTrain));
             answer = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryAnswer)).getAttribute("title");
            if(answer.equals("Fallback Msg Shown")==false)
                break;
        }
        String previousResponse ="";

        CommonFunctionalities.trainBot(trainButton,null,response);
        previousResponse = Utility.driver.findElement(By.xpath(TrainBotPageFactory.tarinBotResponse)).getText();
        Thread.sleep(4000);
        Utility.driver.navigate().refresh();


        boolean staleElement = true;
        while(staleElement){
            try{
                Utility.driver.findElement(By.xpath("("+HistoryPageFactory.faqHistoryTrainButton+")["+i+"]")).click();
                staleElement = false;

            } catch(StaleElementReferenceException e){
                staleElement = true;
            }
        }
        Thread.sleep(3000);
          String updatedResponse=null;
        while(isNull(updatedResponse)) {
            updatedResponse=Utility.driver.findElement(By.xpath(TrainBotPageFactory.tarinBotResponse)).getText();
        }
        org.testng.Assert.assertTrue(updatedResponse.equals(previousResponse),"Response is not getting updated");



    }
    public static void existingFaqTrainWithQuestionAndResponse(String[] questions,String response) throws InterruptedException {

        String answer=null;
        WebElement trainButton =null;
        int i = 1;
        List<WebElement> faqHistoriesList = Utility.driver.findElements(By.xpath(HistoryPageFactory.faqHistoriesList));
        for ( i = 1; i <= faqHistoriesList.size(); i++
                ) {

            trainButton = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryTrain));
            answer = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryAnswer)).getAttribute("title");
            if(answer.equals("Fallback Msg Shown")==false)
                break;
        }
        String previousResponse ="";

        CommonFunctionalities.trainBot(trainButton,questions,response);
        previousResponse = Utility.driver.findElement(By.xpath(TrainBotPageFactory.tarinBotResponse)).getText();
        Thread.sleep(5000);
        //Utility.driver.navigate().refresh();


        boolean staleElement = true;
        while(staleElement){
            try{
                Utility.driver.findElement(By.xpath("("+HistoryPageFactory.faqHistoryTrainButton+")["+i+"]")).click();
                staleElement = false;

            } catch(StaleElementReferenceException e){
                staleElement = true;
            }
        }
        Thread.sleep(3000);
        String updatedResponse="";
        List<WebElement> responseList = Utility.driver.findElements(By.xpath(TrainBotPageFactory.tarinBotResponse));
        if(responseList.size() > 1)
            updatedResponse = Utility.driver.findElement(By.xpath(TrainBotPageFactory.tarinBotResponse+"["+responseList.size()+"]")).getText();
        else updatedResponse = Utility.driver.findElement(By.xpath(TrainBotPageFactory.tarinBotResponse)).getText();
        System.out.println(updatedResponse);
        Assert.assertTrue(updatedResponse.equals(previousResponse),"Response is not getting updated");


    }

    public static void nonExistingFaqTrainWithResponse(String response) throws InterruptedException {
        String answer=null;
        WebElement trainButton =null;
        int i = 1;
        List<WebElement> faqHistoriesList = Utility.driver.findElements(By.xpath(HistoryPageFactory.faqHistoriesList));
        for ( i = 1; i <= faqHistoriesList.size(); i++
                ) {

            trainButton = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryTrain));
            answer = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryAnswer)).getAttribute("title");
            if(answer.equals("Fallback Msg Shown"))
                break;
        }
        String previousResponse ="";

         CommonFunctionalities.trainBot(trainButton,null,response);
        Thread.sleep(5000);
        //Utility.driver.navigate().refresh();


        boolean staleElement = true;
        while(staleElement){
            try{
                Utility.driver.findElement(By.xpath("("+HistoryPageFactory.faqHistoryTrainButton+")["+i+"]")).click();
                staleElement = false;

            } catch(StaleElementReferenceException e){
                staleElement = true;
            }
        }
        Thread.sleep(3000);
        String updatedResponse = Utility.driver.findElement(By.xpath(TrainBotPageFactory.tarinBotResponse)).getText();
        System.out.println(updatedResponse);
        Assert.assertTrue(!updatedResponse.equals(previousResponse),"Response is not getting updated");


    }
    public static void nonExistingFaqTrainWithQuestionAndResponse(String[] questions,String response) throws InterruptedException {
        String answer=null;
        WebElement trainButton =null;
        int i = 1;
        List<WebElement> faqHistoriesList = Utility.driver.findElements(By.xpath(HistoryPageFactory.faqHistoriesList));
        for ( i = 1; i <= faqHistoriesList.size(); i++
                ) {

            trainButton = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryTrain));
            answer = Utility.driver.findElement(By.xpath(HistoryPageFactory.faqHistoriesList + "[" + i + "]/" + HistoryPageFactory.faqHistoryAnswer)).getAttribute("title");
            if(answer.equals("Fallback Msg Shown"))
                break;
        }
        String previousResponse ="";

        CommonFunctionalities.trainBot(trainButton,questions,response);
        Thread.sleep(5000);
        //Utility.driver.navigate().refresh();


        boolean staleElement = true;
        while(staleElement){
            try{
                Utility.driver.findElement(By.xpath("("+HistoryPageFactory.faqHistoryTrainButton+")["+i+"]")).click();
                staleElement = false;

            } catch(StaleElementReferenceException e){
                staleElement = true;
            }
        }
        Thread.sleep(3000);
        String updatedResponse="";
        List<WebElement> responseList = Utility.driver.findElements(By.xpath(TrainBotPageFactory.tarinBotResponse));
        if(responseList.size() > 1)
            updatedResponse = Utility.driver.findElement(By.xpath(TrainBotPageFactory.tarinBotResponse+"["+responseList.size()+"]")).getText();
        else updatedResponse = Utility.driver.findElement(By.xpath(TrainBotPageFactory.tarinBotResponse)).getText();
        System.out.println(updatedResponse);
        Assert.assertTrue(!updatedResponse.equals(previousResponse),"Response is not getting updated");

    }
}