package implementations;

public class FAQUserInformation {
}
