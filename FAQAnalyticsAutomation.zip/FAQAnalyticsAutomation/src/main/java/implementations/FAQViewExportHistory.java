package implementations;

import objectrepo.ViewExportHistoryPageFactory;
import org.openqa.selenium.By;
import org.testng.Assert;
import utilities.Utility;

import java.sql.Driver;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FAQViewExportHistory {

    static Logger logger = Logger.getLogger(Driver.class.getName());

    public static void DownloadingTheCSVFileandChceking() {

        logger.log(Level.INFO, "Downloading CSV file and opening the view export history");

        Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.exportToCsvButton)).click();
        Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.viewExportHistoryLink)).click();
        Utility.waitTillContetLoads(1000);
        String temp = Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.gettingFirstRowProgress)).getText();
        String value = Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.downloadButton)).getAttribute("disabled");

        if (temp.equals("In Progress"))
            Assert.assertEquals(value, "true", "The Download button is getting Enabled during In Progresss");
        Utility.driver.navigate().refresh();
        Utility.waitTillContetLoads(1000);
        Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.downloadButton)).click();
    }

    public static void sortingAndChecking() throws ParseException, InterruptedException {
        logger.log(Level.INFO, "sorting the view export history results and verifying whether it is getting sorted");
        Utility.waitTillContetLoads(2000);
        Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.viewExportHistoryLink)).click();
        Utility.waitTillContetLoads(2000);
        Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.sortingByRequestedTime)).click();
        Utility.waitTillContetLoads(2000);
        SimpleDateFormat simpleDateFormatPrevious = new SimpleDateFormat("MM/dd/yyyy HH:mma");
        SimpleDateFormat simpleDateFormatCurrent = new SimpleDateFormat("MM/dd/yyyy HH:mma");
        String temp = "";
        for (int i = 2; i < 5; i++) {
            temp = Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.requestTime.replace("%s", new Integer(i - 1).toString()))).getText();
            Date previousDate = simpleDateFormatPrevious.parse(temp);
            Thread.sleep(3000);
            temp = Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.requestTime.replace("%s", new Integer(i).toString()))).getText();
            Date currentDate = simpleDateFormatCurrent.parse(temp);
            Assert.assertTrue((previousDate.compareTo(currentDate) <= 0), "Export History is not sorted");
        }
        Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.sortingByRequestedTime)).click();
        Utility.waitTillContetLoads(2000);
        for (int i = 2; i < 5; i++) {
            temp = Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.completeTime.replace("%s", new Integer(i - 1).toString()))).getText();
            Date previousDate = simpleDateFormatPrevious.parse(temp);
            temp = Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.completeTime.replace("%s", new Integer(i).toString()))).getText();
            Date currentDate = simpleDateFormatCurrent.parse(temp);
            Assert.assertTrue((previousDate.compareTo(currentDate) >= 0), "Export History is not sorted");
        }

    }


}