package implementations;

import objectrepo.ViewExportHistoryPageFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import utilities.Utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FAQViewExportHistory {
    public static void DownloadingTheCSVFileandChceking() {

        Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.ExportToCsvButton)).click();
        Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.ViewExportHistoryLink)).click();
        Utility.waitTillContetLoads(1000);
        String temp = Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.gettingFirstRowProgress)).getText();
        String value = Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.DownloadButton)).getAttribute("disabled");

        if (temp.equals("In Progress"))
            Assert.assertEquals(value, "true", "The Download button is getting Enabled during In Progresss");
        Utility.driver.navigate().refresh();
        Utility.waitTillContetLoads(1000);
        Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.DownloadButton)).click();
    }

    public static void sortingAndChecking() throws ParseException, InterruptedException {
        Utility.waitTillContetLoads(2000);
        Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.ViewExportHistoryLink)).click();
        Utility.waitTillContetLoads(2000);
        Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.sortingByRequestedTime)).click();
        Utility.waitTillContetLoads(2000);
        SimpleDateFormat simpleDateFormatPrevious = new SimpleDateFormat("MM/dd/yyyy HH:mma");
        SimpleDateFormat simpleDateFormatCurrent = new SimpleDateFormat("MM/dd/yyyy HH:mma");
        String temp = "";
        for (int i = 2; i < 5; i++) {
            temp = Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.RequestTime.replace("%s", new Integer(i - 1).toString()))).getText();
            Date previousDate = simpleDateFormatPrevious.parse(temp);
            Thread.sleep(3000);
            temp = Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.RequestTime.replace("%s", new Integer(i).toString()))).getText();
            Date currentDate = simpleDateFormatCurrent.parse(temp);
            Assert.assertTrue((previousDate.compareTo(currentDate) <= 0),"Export History is not sorted");
        }
        Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.sortingByRequestedTime)).click();
        Utility.waitTillContetLoads(2000);
        for (int i = 2; i < 5; i++) {
            temp = Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.completeTime.replace("%s", new Integer(i - 1).toString()))).getText();
            Date previousDate = simpleDateFormatPrevious.parse(temp);
            temp = Utility.driver.findElement(By.xpath(ViewExportHistoryPageFactory.completeTime.replace("%s", new Integer(i).toString()))).getText();
            Date currentDate = simpleDateFormatCurrent.parse(temp);
            Assert.assertTrue((previousDate.compareTo(currentDate) >= 0),"Export History is not sorted");
        }

    }


}