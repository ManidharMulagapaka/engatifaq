package objectrepo;

public class ViewExportHistoryPageFactory {

    public static String exportToCsvButton = "//button[@class='btn btn-primary export-csv-btn ng-binding ng-scope']";

    public static String gettingFirstRowProgress = "(//tbody[@class='ng-scope']/tr/td[3]/span)[1]";

    public static String downloadButton = "(//tbody[@class='ng-scope']/tr/td[4]/button)[1]";

    public static String viewExportHistoryLink = "//*[text()='View Export History']";

    public static String sortingByRequestedTime = "//*[@id='DataTables_Table_0']/thead/tr/th[1]";

    public static String requestTime = "(//*[@id='DataTables_Table_0']/tbody/tr/td[1])[%s]";

    public static String completeTime = "(//*[@id='DataTables_Table_0']/tbody/tr/td[2])[1]";

    public static String[] botXpaths = {"//div[@id='botName']", "//*[@id='menu1']/div/div/a[text()='Api']"};

}