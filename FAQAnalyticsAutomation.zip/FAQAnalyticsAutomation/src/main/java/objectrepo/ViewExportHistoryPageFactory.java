package objectrepo;

public class ViewExportHistoryPageFactory {
    public static String ExportToCsvButton="//button[@class='btn btn-primary export-csv-btn ng-binding ng-scope']";
    public static String SortingByDate = "//*[@id='DataTables_Table_1']/thead/tr/th[1]";
    public static String gettingFirstRowProgress = "(//tbody[@class='ng-scope']/tr/td[3]/span)[1]";
    public static String DownloadButton = "(//tbody[@class='ng-scope']/tr/td[4]/button)[1]";
    public static String ViewExportHistoryLink="//*[text()='View Export History']";
    public static String sortingByRequestedTime = "//*[@id='DataTables_Table_0']/thead/tr/th[1]";
    public static String sortingByCompletedTime ="//*[@id=DataTables_Table_0']/thead/tr/th[2]";
    public static String RequestTime = "(//*[@id='DataTables_Table_0']/tbody/tr/td[1])[%s]";
    public static String completeTime ="(//*[@id='DataTables_Table_0']/tbody/tr/td[2])[1]";
    public static String[] botXpaths = {"//div[@id='botName']","//*[@id=\"menu1\"]/div/div/a[text()='Api']"};
 /*   public static String  ListOfCsvFiles="//td[@class='ng-binding sorting_1']";
    public static String StatusInProgressVer="//span[@ng-bind='setLabels.fileStatus.inProgress']";
    public static String StatusCompletedVer="//*[@id='DataTables_Table_0']/tbody/tr[2]/td[3]/span";
    public static String CompletedStatusVal="//*[@id='DataTables_Table_0']/tbody/tr[1]/td[4]/button";
    public static String InProgressStatusVal="//*[@id='DataTables_Table_0']/tbody/tr[2]/td[3]/span";
    public static String EnDownloadButton="//button[@class='btn btn-primary ng-binding']";
    public static String DsDownloadButton="//*[@id='DataTables_Table_0\"]/tbody/tr[2]/td[3]/span"+"//button[@class=\"btn btn-primary ng-binding\"]";
    public static String ShowDropDown="//*[@class=\"itemperpageDropdown ng-pristine ng-valid ng-not-empty ng-touched\"]";*/

}