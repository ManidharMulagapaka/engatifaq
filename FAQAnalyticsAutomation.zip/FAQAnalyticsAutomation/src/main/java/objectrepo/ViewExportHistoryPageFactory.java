package objectrepo;

public class ViewExportHistoryPageFactory {
}
