package objectrepo;

public class HistoryPageFactory {
}
