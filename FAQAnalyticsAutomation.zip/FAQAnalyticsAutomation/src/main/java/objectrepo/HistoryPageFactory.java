package objectrepo;

public class HistoryPageFactory {
    public static String faqAnalyticsTab = "//*[@id='menu']/ul/li[@class='panel ng-scope']/a[text()=' FAQ Analytics']";

    public static String entriesSelect = "//div[@id='faqanalyticsrow']/div[1]/div[1]/select";

    public static String pageDivision = "//div[@class='faqanalyticstable']/ul/li";

    public static String lastActiveFilter = "//div[@id='firstLevelNav_small']/button";

    public static String applyButton = "//div[@class='row ng-scope']/div[4]/button";

    public static String lastActivedropdownAny = "//div[@id='firstLevelNav_small']/ul/li[1]/a/div";

    public static String responseTypeButton = "//label[@id='answerShownValue']";

    public static String responseTypedropdown = "//div[@id='thirdLevelNav_small']/ul/li";

    public static String responsedivision = "/a/div";

    public static String responseHelpfulButton = "responseValue";

    public static String responseHelpfulValue = "//div[@id='secondLevelNav_small']/ul/li[4]/a/div";

    public static String faqHistoriesList = "//table[@id='faq_analytics_datatable']/tbody/tr";

    public static String faqHistoryDateTime = "td[8]";

    public static String lastActiveFilter24Hours = "//div[@id='firstLevelNav_small']/ul/li[2]/a/div";

    public static String lastActiveFilter7days = "//div[@id='firstLevelNav_small']/ul/li[3]/a/div";

    public static String lastActiveFilterFromDate = "//div[@id='firstLevelNav_small']/ul/li[4]/ul/div[1]/div[1]/datepicker/input";

    public static String lastActiveFilterToDate = "//div[@id='firstLevelNav_small']/ul/li[4]/ul/div[1]/div[2]/datepicker/input";

    public static String lastActiveFilterApply = "//div[@id='firstLevelNav_small']/ul/li[4]/ul/div[2]/button[1]";

    public static String faqHistoryAnswer = "td[5]/div";

    public static String faqHistoryTrain = "td[3]/button";

    public static String faqHistoryTrainButton = "(//tr[@id='faq_analytics_data']/td[3]/button)";

    public static String answers = "(//*[@id='faq_analytics_data']/td[5]/div)[%s]";

    public static String requests = "(//*[@id='faq_analytics_data']/td[1]/div)[%s]";

    public static String partial = "(//*[@id='faq_analytics_data']/td[2]/div)[%s]";

    public static String accuracy = "(//*[@id='faq_analytics_data']/td[7])[%s]";

    public static String sortScore = "//*[contains(text(),'Score')]";

    public static String sortDate = "//*[contains(text(),'Date and Time')]";

    public static String Score = "(//*[@class='ng-binding sorting_1'])[%s]";

    public static String date = "(//*[@id='faq_analytics_data']/td[8])[%s]";

    public static String searchBox = "//*[@class='fw-600']/input";

    public static String searchButton = "//button[@class='btn btn-primary btn-circle']";

    public static String exportCSV = "//button[text()='Export to CSV']";

    public static String nOResults = "//table[@id='faq_analytics_datatable']/tbody/tr/td";

    public static String[] botXpaths = {"//div[@id='botName']", "//*[@id=\"menu1\"]/div/div/a[text()='Api']"};

    public static String[] withoutInitalization = {"//div[@id='botName']", "//*[@id=\"menu1\"]/div/div/a[text()='Sample']"};

    public static String[] withInitalization = {"//div[@id='botName']", "//*[@id=\"menu1\"]/div/div/a[text()='Sample1']"};

    public static String defaultMessage = "//div[@class='no_data_text']/span";

    public static String failFilteringsubXpath = "td";
}
