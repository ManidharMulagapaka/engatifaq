package objectrepo;

public class TrainBotPageFactory {

    public static String tarinBotResponse = "//div[@id='myModal']/div/div/div[2]/div[3]/div[2]/ul/li";

    public static String addNewResponse = "//div[@id='myModal']/div/div/div[2]/div[5]/div[2]/textarea";

    public static String addButton = "//div[@id='myModal']/div/div/div[2]/button";

    public static String addQuestions = "//tags-input[@id='variations']/div/div/input";

    public static String[] botXpaths = {"//div[@id='botName']", "//*[@id=\"menu1\"]/div/div/a[text()='Api']"};

}
