package objectrepo;

public class InteractionsPageFactory {
    public static String changeBotDropDown = "//*[@id='mainmenu']/div/a/span";

    public static String changeBot = "//div[@id='menu1']/div[@class='botWidget ng-scope']/div/a[text()='User']";

    public static String FAQAnalytics = "//li[@class='panel ng-scope']/a[text()=' FAQ Analytics']";

    public static String SelectingTopRow = "(//table[@id='faq_analytics_datatable']/tbody/tr)[1]";

    public static String DateAcquired = "//*[@class='pt-5']/span"; //getText and use as date

    public static String UserName = "//*[@class='col-md-4']/label[text()='Website User']";

    public static String FrequesntMessage = "(//*[@class='frequent_message']/div/span)[%s]";

    public static String Messages = "(//*[@class='chatbox__messages__user-message--ind-message chatbox_userdetail_messages']/p)[%s]";

    public static String numberOfInteractions = "//*[@class='userDetailMetrics']/label[@ng-model='no_of_conversations_for_user']";

    public static String[] botXpaths = {"//div[@id='botName']","//*[@id=\"menu1\"]/div/div/a[text()='API']"};

}
