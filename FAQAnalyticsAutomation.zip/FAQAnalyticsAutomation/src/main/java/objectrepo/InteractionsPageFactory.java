package objectrepo;

public class InteractionsPageFactory {

    public static String selectingTopRow = "(//table[@id='faq_analytics_datatable']/tbody/tr)[1]";

    public static String dateAcquired = "//*[@class='pt-5']/span";

    public static String userName = "//*[@class='col-md-4']/label[text()='Website User']";

    public static String messages = "(//*[@class='chatbox__messages__user-message--ind-message chatbox_userdetail_messages']/p)[%s]";

    public static String[] botXpaths = {"//div[@id='botName']", "//*[@id=\"menu1\"]/div/div/a[text()='API']"};

}
