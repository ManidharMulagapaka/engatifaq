package objectrepo;

public class InteractionsPageFactory {
}
