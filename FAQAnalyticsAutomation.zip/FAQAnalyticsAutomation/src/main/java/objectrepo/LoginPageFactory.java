package objectrepo;

public class LoginPageFactory {

    public static String LoginUserNameTextBox = "//*[@id='username'][@name='username']";

    public static String LoginPasswordTextBox =  "//*[@id='password'][@name='password'][@type='password']";

    public static  String LoginButton = "//button[@type='submit'][@id='signin']";
}
