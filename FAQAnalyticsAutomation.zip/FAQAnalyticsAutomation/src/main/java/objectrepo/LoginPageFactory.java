package objectrepo;

public class LoginPageFactory {

    public static String loginUserNameTextBox = "//*[@id='username'][@name='username']";

    public static String loginPasswordTextBox = "//*[@id='password'][@name='password'][@type='password']";

    public static String loginButton = "//button[@type='submit'][@id='signin']";
}
