package testcases;

import EnvSetters.HistoryEnvSetter;
import EnvSetters.HomeEnvSetter;
import implementations.FAQHistory;
import implementations.FAQHistorySearch;
import objectrepo.HistoryPageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;
import utilities.CommonFunctionalities;
import utilities.Utility;

import java.io.IOException;
import java.text.ParseException;

  public class FAQHistoryTest extends Utility {

      @Test(priority = 1)
      public void verifyingHistories() throws IOException, InterruptedException {
          HistoryEnvSetter.historyProperties();
          CommonFunctionalities.openBot(HistoryPageFactory.botXpaths);
          FAQHistory.comparing();
      }


      @Test(priority = 2)
      public void faqPaginationTest() throws IOException, InterruptedException {
          HistoryEnvSetter.historyProperties();
          CommonFunctionalities.openBot(HistoryPageFactory.botXpaths);
          FAQHistory.checkFaqPaginations();



    }

     @Test(priority = 3)
    public void faqFilterCombinationsPositiveTest() throws InterruptedException, IOException, ParseException {

         HistoryEnvSetter.historyProperties();
         CommonFunctionalities.openBot(HistoryPageFactory.botXpaths);

        for (int i=0;i<HistoryEnvSetter.lastActiveFilter.length;i++)
             {

            FAQHistory.faqFilters(HistoryEnvSetter.lastActiveFilter[i],HistoryEnvSetter.responseFoundFilter[i],HistoryEnvSetter.responseHelpfulFilter[i]);
        }

        for (int i=0;i<HistoryEnvSetter.lastActiveWithOutput.length;i++){
            FAQHistory.faqFilters(HistoryEnvSetter.lastActiveWithOutput[i],HistoryEnvSetter.responseFoundFilter[0],HistoryEnvSetter.responseHelpfulFilter[i]);
        }

    }
    @Test(priority = 4)
    public void faqFilterCombinationsNegativeTest() throws ParseException, InterruptedException, IOException {
        HistoryEnvSetter.historyProperties();
        CommonFunctionalities.openBot(HistoryPageFactory.botXpaths);
        for(int i=0;i<HistoryEnvSetter.lastActiveWithOutOutput.length;i++){
            FAQHistory.faqFailFilters(HistoryEnvSetter.lastActiveWithOutOutput[i]);

        }
    }
}
