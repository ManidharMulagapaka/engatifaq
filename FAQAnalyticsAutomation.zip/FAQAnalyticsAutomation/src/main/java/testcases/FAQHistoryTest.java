package testcases;

import org.testng.annotations.Test;
import utilities.Utility;

public class FAQHistoryTest extends Utility {

    @Test
    public void print(){
        System.out.println("Kani");
    }


}
