package testcases;

import EnvSetters.HistoryEnvSetter;
import implementations.FAQHistory;
import objectrepo.HistoryPageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import utilities.CommonFunctionalities;
import utilities.Utility;

import java.io.IOException;
import java.sql.Driver;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FAQHistoryTest extends Utility {
    static Logger logger = Logger.getLogger(Driver.class.getName());

    @BeforeTest
    public static void propertySetUp() throws IOException {
        HistoryEnvSetter.historyProperties();
        logger.log(Level.INFO, "History page properties are loaded successfully");
    }


    @Test(priority = 3)
    public void verifyingHistories() throws InterruptedException {

        CommonFunctionalities.openBot(HistoryPageFactory.botXpaths);
        FAQHistory.verifyingHistoryDetails();
    }


    @Test(priority = 4)
    public void faqPaginationTest() throws InterruptedException {

        CommonFunctionalities.openBot(HistoryPageFactory.botXpaths);
        FAQHistory.checkFaqPaginations();

    }

    @Test(priority = 5)
    public void faqFilterCombinationsPositiveTest() throws InterruptedException, ParseException {


        CommonFunctionalities.openBot(HistoryPageFactory.botXpaths);

        for (int i = 0; i < HistoryEnvSetter.lastActiveFilter.length; i++) {

            FAQHistory.faqFilters(HistoryEnvSetter.lastActiveFilter[i], HistoryEnvSetter.responseFoundFilter[i], HistoryEnvSetter.responseHelpfulFilter[i]);
        }

        for (int i = 0; i < HistoryEnvSetter.lastActiveWithOutput.length; i++) {
            FAQHistory.faqFilters(HistoryEnvSetter.lastActiveWithOutput[i], HistoryEnvSetter.responseFoundFilter[0], HistoryEnvSetter.responseHelpfulFilter[i]);
        }

    }

    @Test(priority = 6)
    public void faqFilterCombinationsNegativeTest() throws InterruptedException {

        CommonFunctionalities.openBot(HistoryPageFactory.botXpaths);
        for (int i = 0; i < HistoryEnvSetter.lastActiveWithOutOutput.length; i++) {
            FAQHistory.faqFailFilters(HistoryEnvSetter.lastActiveWithOutOutput[i]);

        }
    }
    @Test(priority = 1)
    public  void chatBotWithoutAnyInitialization() throws InterruptedException {
        CommonFunctionalities.openBot(HistoryPageFactory.withoutInitalization);
        FAQHistory.chatBotWithoutInitalzation();
    }

    @Test(priority = 2)
    public void chatBotWithInitialization() throws InterruptedException {
        CommonFunctionalities.openBot(HistoryPageFactory.withInitalization);
        FAQHistory.chatBotWithInitalzation();
    }
}
