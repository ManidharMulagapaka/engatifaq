package testcases;

public class FAQHistorySearchTest {
}
