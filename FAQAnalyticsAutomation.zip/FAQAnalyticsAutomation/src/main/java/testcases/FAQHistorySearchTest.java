package testcases;

import EnvSetters.HomeEnvSetter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import utilities.Utility;

import java.io.IOException;

public class FAQHistorySearchTest {

    @BeforeTest
    void intializations() throws IOException {
        HomeEnvSetter.intialize();
        Utility.intialize();
    }

    @Test
    void Sample(){

    }


    @AfterTest
    void stop(){
        Utility.Destructing();


    }

}


