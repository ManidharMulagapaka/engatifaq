package testcases;


import EnvSetters.HistoryEnvSetter;
import implementations.FAQHistorySearch;
import objectrepo.HistoryPageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import utilities.CommonFunctionalities;
import utilities.Utility;

import java.io.IOException;
import java.sql.Driver;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FAQHistorySearchTest extends Utility {

    static Logger logger = Logger.getLogger(Driver.class.getName());

    @BeforeTest
    public static void propertySetUp() throws IOException {
        logger.log(Level.INFO,"Setting up the properties of Search Test");
        HistoryEnvSetter.historyProperties();
    }


    @Test()
    public void sortingHistory() throws IOException, InterruptedException, ParseException {

        CommonFunctionalities.openBot(HistoryPageFactory.botXpaths);
        FAQHistorySearch.sortingAndVerifyingScore();
        FAQHistorySearch.sortingAndVerifyingDate();

    }

    @Test()
    public void searchingForARecordInHistory() throws IOException, InterruptedException {

        CommonFunctionalities.openBot(HistoryPageFactory.botXpaths);
        FAQHistorySearch.searchingForAWordInSearch(HistoryEnvSetter.validSearch);

    }

    @Test()
    public void searchingForAInValidRecordInHistory() throws IOException, InterruptedException {

        CommonFunctionalities.openBot(HistoryPageFactory.botXpaths);
        FAQHistorySearch.searchingForAInValidRecordInHistory(HistoryEnvSetter.invalidSearch);


    }


    @Test()
    public void csvButtonVerification() throws IOException, InterruptedException {

        CommonFunctionalities.openBot(HistoryPageFactory.botXpaths);
        FAQHistorySearch.verifyingCSVButton(HistoryEnvSetter.invalidSearch);
    }


}




