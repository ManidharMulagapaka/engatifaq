package testcases;



import EnvSetters.HistoryEnvSetter;
import implementations.FAQHistorySearch;
import objectrepo.HistoryPageFactory;
import org.testng.annotations.Test;
import utilities.CommonFunctionalities;
import utilities.Utility;

import java.io.IOException;
import java.text.ParseException;

public class FAQHistorySearchTest extends Utility{


    @Test()
    public void sortingHistory() throws IOException, InterruptedException, ParseException {

        HistoryEnvSetter.historyProperties();
        CommonFunctionalities.openBot(HistoryPageFactory.botXpaths);
       FAQHistorySearch.sortingAndVerifyingScore();
       FAQHistorySearch.sortingAndVerifyingDate();

    }

    @Test()
    public void searchingForARecordInHistory() throws IOException, InterruptedException {
        HistoryEnvSetter.historyProperties();
        CommonFunctionalities.openBot(HistoryPageFactory.botXpaths);
        FAQHistorySearch.searchingForAWordInSearch(HistoryEnvSetter.validSearch);

    }

    @Test()
    public void searchingForAInValidRecordInHistory() throws IOException, InterruptedException {
        HistoryEnvSetter.historyProperties();
        CommonFunctionalities.openBot(HistoryPageFactory.botXpaths);
        FAQHistorySearch.searchingForAInValidRecordInHistory(HistoryEnvSetter.invalidSearch);


    }


    @Test()
    public void CSVButtonVerification() throws IOException, InterruptedException {
        HistoryEnvSetter.historyProperties();
        CommonFunctionalities.openBot(HistoryPageFactory.botXpaths);
        FAQHistorySearch.verifyingCSVButton(HistoryEnvSetter.invalidSearch);
    }


}




