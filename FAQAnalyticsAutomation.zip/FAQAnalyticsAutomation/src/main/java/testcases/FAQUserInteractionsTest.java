package testcases;

import EnvSetters.HistoryEnvSetter;
import EnvSetters.InteractionsEnvSetter;
import implementations.FAQUserInteractions;
import objectrepo.InteractionsPageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import utilities.CommonFunctionalities;
import utilities.Utility;

import java.io.IOException;
import java.sql.Driver;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FAQUserInteractionsTest extends Utility {

    static Logger logger = Logger.getLogger(Driver.class.getName());

    @BeforeTest
    public static void propertySetUp() throws IOException {
        InteractionsEnvSetter.setProperties();
        logger.log(Level.INFO, "User Interactions page properties are loaded successfully");
    }
    @Test
    public void checkingUserInformation() throws IOException, InterruptedException {

        CommonFunctionalities.openBot(InteractionsPageFactory.botXpaths);
        FAQUserInteractions.checkingUserInformation();


    }

    @Test
    public void checkingUserInteractions() throws IOException, InterruptedException {

        CommonFunctionalities.openBot(InteractionsPageFactory.botXpaths);
        FAQUserInteractions.checkingUserInteractions();
    }
}
