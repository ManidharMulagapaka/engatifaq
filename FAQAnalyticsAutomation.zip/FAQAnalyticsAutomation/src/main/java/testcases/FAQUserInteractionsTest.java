package testcases;

import EnvSetters.InteractionsEnvSetter;
import implementations.FAQUserInteractions;
import objectrepo.InteractionsPageFactory;
import org.testng.annotations.Test;
import utilities.CommonFunctionalities;
import utilities.Utility;

import java.io.IOException;

public class FAQUserInteractionsTest extends Utility {
    @Test
    public void checkingUserInformation() throws IOException, InterruptedException {
        InteractionsEnvSetter.initialize();
        CommonFunctionalities.openBot(InteractionsPageFactory.botXpaths);
        FAQUserInteractions.checkingUserInformation();


    }

    @Test
    public void checkingUserInteractions() throws IOException, InterruptedException {
        InteractionsEnvSetter.initialize();
        CommonFunctionalities.openBot(InteractionsPageFactory.botXpaths);
        FAQUserInteractions.checkingUserInteractions();
    }
}
