package testcases;

import implementations.FAQViewExportHistory;
import objectrepo.ViewExportHistoryPageFactory;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import utilities.CommonFunctionalities;
import utilities.Utility;

import java.io.IOException;
import java.text.ParseException;

public class FAQViewExportHistoryTest extends Utility{
    @Test
    public void ExportingCsvFileAndVerifying() throws IOException, InterruptedException {
        CommonFunctionalities.openBot(ViewExportHistoryPageFactory.botXpaths);
        FAQViewExportHistory.DownloadingTheCSVFileandChceking();
    }

    @Test
    public void SortinginCSVFile() throws IOException, ParseException, InterruptedException {
        CommonFunctionalities.openBot(ViewExportHistoryPageFactory.botXpaths);
        FAQViewExportHistory.sortingAndChecking();
    }
}
