package testcases;

import EnvSetters.TrainBotEnvSetter;
import implementations.FAQTrainBot;
import objectrepo.HistoryPageFactory;
import objectrepo.TrainBotPageFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import utilities.CommonFunctionalities;
import utilities.Utility;
import java.io.IOException;

public class FAQTrainBotTest extends Utility {


    @Test(priority = 1)
    public static void existingFaqTrainWithResponse() throws IOException, InterruptedException {

        TrainBotEnvSetter.setProperties();
        CommonFunctionalities.openBot(TrainBotPageFactory.botXpaths);
        FAQTrainBot.existingFaqTrainWithResponse(TrainBotEnvSetter.response);
    }


    @Test(priority = 2)
    public static void existingFaqTrainWithQuestionAndResponse() throws IOException, InterruptedException {
        TrainBotEnvSetter.setProperties();
        CommonFunctionalities.openBot(TrainBotPageFactory.botXpaths);
        FAQTrainBot.existingFaqTrainWithQuestionAndResponse(TrainBotEnvSetter.questions,TrainBotEnvSetter.response);


    }


   @Test(priority = 3)
    public static void nonExistingFaqTrainWithResponse() throws IOException, InterruptedException {
        TrainBotEnvSetter.setProperties();
       CommonFunctionalities.openBot(TrainBotPageFactory.botXpaths);
        FAQTrainBot.nonExistingFaqTrainWithResponse(TrainBotEnvSetter.response);



    }


    @Test(priority = 4)
    public static void nonExistingFaqTrainWithQuestionAndResponse() throws IOException, InterruptedException {
        TrainBotEnvSetter.setProperties();
        CommonFunctionalities.openBot(TrainBotPageFactory.botXpaths);
         FAQTrainBot.nonExistingFaqTrainWithQuestionAndResponse(TrainBotEnvSetter.questions,TrainBotEnvSetter.response);

    }

}
