package testcases;

import EnvSetters.TrainBotEnvSetter;
import implementations.FAQTrainBot;
import objectrepo.TrainBotPageFactory;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import utilities.CommonFunctionalities;
import utilities.Utility;

import java.io.IOException;
import java.sql.Driver;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FAQTrainBotTest extends Utility {
    static Logger logger = Logger.getLogger(Driver.class.getName());

    @BeforeMethod
    public static void propertySetUp() throws IOException {
        TrainBotEnvSetter.setProperties();
        logger.log(Level.INFO, "TrainBot page properties are loaded successfully");
    }


    @Test(priority = 1)
    public static void existingFaqTrainWithResponse() throws InterruptedException {

        CommonFunctionalities.openBot(TrainBotPageFactory.botXpaths);
        FAQTrainBot.existingFaqTrainWithResponse(TrainBotEnvSetter.response);
    }


    @Test(priority = 2)
    public static void existingFaqTrainWithQuestionAndResponse() throws InterruptedException {


        CommonFunctionalities.openBot(TrainBotPageFactory.botXpaths);
        FAQTrainBot.existingFaqTrainWithQuestionAndResponse(TrainBotEnvSetter.questions, TrainBotEnvSetter.response);


    }


    @Test(priority = 3)
    public static void nonExistingFaqTrainWithResponse() throws InterruptedException {


        CommonFunctionalities.openBot(TrainBotPageFactory.botXpaths);
        FAQTrainBot.nonExistingFaqTrainWithResponse(TrainBotEnvSetter.response);


    }


    @Test(priority = 4)
    public static void nonExistingFaqTrainWithQuestionAndResponse() throws InterruptedException {

        CommonFunctionalities.openBot(TrainBotPageFactory.botXpaths);
        FAQTrainBot.nonExistingFaqTrainWithQuestionAndResponse(TrainBotEnvSetter.questions, TrainBotEnvSetter.response);

    }

}
