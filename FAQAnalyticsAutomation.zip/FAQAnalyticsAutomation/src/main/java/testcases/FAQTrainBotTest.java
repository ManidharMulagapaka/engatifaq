package testcases;

public class FAQTrainBotTest {
}
